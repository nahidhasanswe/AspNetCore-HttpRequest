﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LogMain
    {
        public long LogId { get; set; }
        public string UserId { get; set; }
        public int? ModuleId { get; set; }
        public string Form { get; set; }
        public string CalledFunction { get; set; }
        public int? ActionId { get; set; }
        public string UserRight { get; set; }
        public string LogMessage { get; set; }
        public string LogRefMessage { get; set; }
        public int? LogTypeId { get; set; }
        public int? StudentId { get; set; }
        public int? InstitutionId { get; set; }
        public string ComputerNo { get; set; }
        public string ComputerName { get; set; }
        public string LoanNumber { get; set; }
        public DateTime? LogTime { get; set; }
        public string Ipaddress { get; set; }
        public bool? IsObj { get; set; }
        public int? LoginInfoId { get; set; }

        public Action Action { get; set; }
        public LogType LogType { get; set; }
        public Module Module { get; set; }
    }
}
