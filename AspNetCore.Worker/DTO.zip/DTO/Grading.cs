﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Grading
    {
        public int GradeId { get; set; }
        public int? ExamTitleId { get; set; }
        public string Grade { get; set; }
        public int? Aps { get; set; }
    }
}
