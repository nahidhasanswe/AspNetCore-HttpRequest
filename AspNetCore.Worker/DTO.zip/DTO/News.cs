﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class News
    {
        public int NewsId { get; set; }
        public int? NewsCategory { get; set; }
        public string NewsTitle { get; set; }
        public string NewsDetails { get; set; }
        public DateTime? PublishDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public int? Status { get; set; }
    }
}
