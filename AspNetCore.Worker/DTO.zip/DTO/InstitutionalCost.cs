﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InstitutionalCost
    {
        public int InstitutionCostId { get; set; }
        public string FinYear { get; set; }
        public int? InstitutionId { get; set; }
        public int? CourseId { get; set; }
        public int? ExpenseId { get; set; }
        public decimal? LastyearCost { get; set; }
        public decimal? CurrentYearCost { get; set; }
        public string CaptuedBy { get; set; }
        public DateTime? CaptureDate { get; set; }

        public Institution Institution { get; set; }
    }
}
