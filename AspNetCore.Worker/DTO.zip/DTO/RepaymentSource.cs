﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class RepaymentSource
    {
        public RepaymentSource()
        {
            RepaymentRegister = new HashSet<RepaymentRegister>();
        }

        public int SourceTypeId { get; set; }
        public string Description { get; set; }

        public ICollection<RepaymentRegister> RepaymentRegister { get; set; }
    }
}
