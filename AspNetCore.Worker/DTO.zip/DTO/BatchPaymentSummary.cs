﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class BatchPaymentSummary
    {
        public int BatchPaymentSummaryId { get; set; }
        public int BatchPaymentId { get; set; }
        public string InvoiceNo { get; set; }
        public string HeadCode { get; set; }
        public decimal Amount { get; set; }
        public short? Status { get; set; }
        public string CapturedBy { get; set; }
        public DateTime CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
    }
}
