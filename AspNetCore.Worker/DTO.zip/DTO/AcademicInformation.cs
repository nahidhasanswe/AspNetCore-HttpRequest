﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AcademicInformation
    {
        public AcademicInformation()
        {
            AcademicResult = new HashSet<AcademicResult>();
        }

        public int AcademicInfoId { get; set; }
        public string LoanYear { get; set; }
        public int StudentId { get; set; }
        public string SchoolName { get; set; }
        public string Address { get; set; }
        public string CountryCode { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? FinishDate { get; set; }
        public int ExamTitleId { get; set; }
        public string OtherExamTitle { get; set; }
        public int FundingSourceId { get; set; }
        public short? Status { get; set; }

        public Country CountryCodeNavigation { get; set; }
        public ExamTitle ExamTitle { get; set; }
        public Student Student { get; set; }
        public ICollection<AcademicResult> AcademicResult { get; set; }
    }
}
