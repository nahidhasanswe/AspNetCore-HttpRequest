﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Voucher
    {
        public int VoucherId { get; set; }
        public string DebtorName { get; set; }
        public string DebtorDepartment { get; set; }
        public string CreditorName { get; set; }
        public string CreditorDepartment { get; set; }
        public string VoucherNo { get; set; }
        public string BatchNumber { get; set; }
        public decimal? VoucherTotalAmount { get; set; }
        public int? VoucherTypeId { get; set; }
        public DateTime? DebtorDateSigned { get; set; }
        public DateTime? CreditorDateSigned { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
    }
}
