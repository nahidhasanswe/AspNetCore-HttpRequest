﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ActualTransaction
    {
        public int AccTransId { get; set; }
        public string TransactionYear { get; set; }
        public string TransactionDate { get; set; }
        public int Payee { get; set; }
        public decimal? DrCrIndicator { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public LoanAccount PayeeNavigation { get; set; }
    }
}
