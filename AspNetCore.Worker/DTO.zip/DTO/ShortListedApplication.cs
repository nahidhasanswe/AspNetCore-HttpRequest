﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ShortListedApplication
    {
        public ShortListedApplication()
        {
            Interview = new HashSet<Interview>();
            InterviewBatchDetails = new HashSet<InterviewBatchDetails>();
        }

        public int ShortListAppsId { get; set; }
        public string ShortListedYear { get; set; }
        public int SelectionId { get; set; }
        public int ApplicationId { get; set; }
        public decimal? MeritScore { get; set; }
        public int? Rank { get; set; }
        public decimal? SocioScore { get; set; }
        public bool? IsDisability { get; set; }
        public bool? IsSsl { get; set; }
        public string SslselectionType { get; set; }
        public bool? IsSaf { get; set; }
        public string SafselectionType { get; set; }
        public bool? InterviewNotificationSent { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public Selection Selection { get; set; }
        public ICollection<Interview> Interview { get; set; }
        public ICollection<InterviewBatchDetails> InterviewBatchDetails { get; set; }
    }
}
