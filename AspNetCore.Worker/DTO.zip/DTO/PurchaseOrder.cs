﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PurchaseOrder
    {
        public int PurchaseOrderId { get; set; }
        public string OrderNumber { get; set; }
        public int? Year { get; set; }
        public string RespCode { get; set; }
        public string ReportingCode { get; set; }
        public string ProjectCode { get; set; }
        public int? SupplierId { get; set; }
        public string SupplierCode { get; set; }
        public decimal? OrderValue { get; set; }
        public string IssedBy { get; set; }
        public DateTime? OrderDate { get; set; }
        public int? Status { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CapturedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
