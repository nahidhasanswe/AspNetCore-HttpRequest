﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Question
    {
        public Question()
        {
            InterviewResponse = new HashSet<InterviewResponse>();
            QuestionManager = new HashSet<QuestionManager>();
            QuestionOption = new HashSet<QuestionOption>();
        }

        public int QuestionId { get; set; }
        public string QuestionDescription { get; set; }
        public decimal? MaxScore { get; set; }
        public decimal? MinScore { get; set; }
        public int QuestionTypeId { get; set; }
        public int QuestionCategoryId { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public QuestionCategory QuestionCategory { get; set; }
        public QuestionType QuestionType { get; set; }
        public ICollection<InterviewResponse> InterviewResponse { get; set; }
        public ICollection<QuestionManager> QuestionManager { get; set; }
        public ICollection<QuestionOption> QuestionOption { get; set; }
    }
}
