﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class OngoingBudget
    {
        public string LoanYear { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
