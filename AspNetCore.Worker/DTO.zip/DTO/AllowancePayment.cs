﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AllowancePayment
    {
        public int AllowancePaymentId { get; set; }
        public int? AllowanceGroupId { get; set; }
        public int? FinanceRequestTypeId { get; set; }
        public decimal? Amount { get; set; }

        public AllowanceGroup AllowanceGroup { get; set; }
    }
}
