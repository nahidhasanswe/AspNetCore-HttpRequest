﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Selection
    {
        public Selection()
        {
            ShortListedApplication = new HashSet<ShortListedApplication>();
        }

        public int SelectionId { get; set; }
        public string SelectionTitle { get; set; }
        public DateTime? SelectionDate { get; set; }
        public int? LoanTypeId { get; set; }
        public string SelectionYear { get; set; }
        public int PriorityAreaAllocationId { get; set; }
        public int? LoanAreaId { get; set; }
        public string SelectedBy { get; set; }
        public string ApprovedBy { get; set; }
        public int? NumberSelected { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public short? LoanCategoryId { get; set; }
        public int? ApplicationSessionId { get; set; }
        public int CourseId { get; set; }

        public ICollection<ShortListedApplication> ShortListedApplication { get; set; }
    }
}
