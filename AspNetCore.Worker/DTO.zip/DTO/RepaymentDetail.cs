﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class RepaymentDetail
    {
        public int RepaymentDetailId { get; set; }
        public int RepaymentId { get; set; }
        public int? AccountId { get; set; }
        public decimal? Amount { get; set; }
        public int? Status { get; set; }
        public string RepaymentCheque { get; set; }

        public RepaymentRegister Repayment { get; set; }
    }
}
