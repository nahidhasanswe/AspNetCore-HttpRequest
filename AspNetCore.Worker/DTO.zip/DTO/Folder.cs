﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Folder
    {
        public Folder()
        {
            PaymentBatch = new HashSet<PaymentBatch>();
        }

        public int FolderId { get; set; }
        public string FolderNo { get; set; }
        public string AcademicYear { get; set; }
        public string ReferenceNo { get; set; }
        public string Description { get; set; }
        public string Location { get; set; }
        public string RoomNo { get; set; }
        public string SelfNo { get; set; }
        public string RowNo { get; set; }
        public int? InstitutionId { get; set; }
        public string Barcode { get; set; }

        public ICollection<PaymentBatch> PaymentBatch { get; set; }
    }
}
