﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Transaction
    {
        public int TransactionId { get; set; }
        public int? ReferenceNo { get; set; }
        public int PaymentBatchId { get; set; }
        public int AccountId { get; set; }
        public short? AccountType { get; set; }
        public int? InstitutionAccountId { get; set; }
        public int? SupplierAccountId { get; set; }
        public int? EmployerId { get; set; }
        public string AccountMasterCode { get; set; }
        public short? DebitCreaditIndicator { get; set; }
        public decimal? Amount { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public short? Status { get; set; }
    }
}
