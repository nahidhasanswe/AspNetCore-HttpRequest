﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Institution
    {
        public Institution()
        {
            AccademicStatus = new HashSet<AccademicStatus>();
            InstitutionalCost = new HashSet<InstitutionalCost>();
            InvoiceRegister = new HashSet<InvoiceRegister>();
        }

        public int InstitutionId { get; set; }
        public string InstitutionCode { get; set; }
        public string CountryCode { get; set; }
        public string InstitutionName { get; set; }
        public string BusinessAddress { get; set; }
        public string PostalAddress { get; set; }
        public string PostCode { get; set; }
        public string Telephone { get; set; }
        public string CellPhone { get; set; }
        public string EmailAddress { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public ICollection<AccademicStatus> AccademicStatus { get; set; }
        public ICollection<InstitutionalCost> InstitutionalCost { get; set; }
        public ICollection<InvoiceRegister> InvoiceRegister { get; set; }
    }
}
