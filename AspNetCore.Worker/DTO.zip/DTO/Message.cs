﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Message
    {
        public int MessageId { get; set; }
        public string Header { get; set; }
        public string Message1 { get; set; }
        public string UserId { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ExpireDate { get; set; }
        public byte? Status { get; set; }
        public byte? Active { get; set; }
        public string RegistryBy { get; set; }
        public DateTime? RegistryDate { get; set; }
        public int? NumberOfRecipient { get; set; }
        public int? MessageCatagory { get; set; }
        public int? SendingType { get; set; }
        public int? ReferanceId { get; set; }
    }
}
