﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ReportingStatus
    {
        public int ReportingStatusId { get; set; }
        public int? StudentId { get; set; }
        public int ApplicationId { get; set; }
        public int ReportingTypeId { get; set; }
        public int? ReportingStatusValue { get; set; }
        public string Notes { get; set; }
        public DateTime? ReportingDate { get; set; }

        public ReportingType ReportingType { get; set; }
    }
}
