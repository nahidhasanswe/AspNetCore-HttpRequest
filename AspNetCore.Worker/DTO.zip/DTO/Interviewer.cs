﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Interviewer
    {
        public int InterviewerId { get; set; }
        public int? InterviewBatchId { get; set; }
        public string InterviewerName { get; set; }
        public byte? Status { get; set; }
    }
}
