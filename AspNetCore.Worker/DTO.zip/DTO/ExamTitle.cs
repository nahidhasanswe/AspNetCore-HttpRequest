﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ExamTitle
    {
        public ExamTitle()
        {
            AcademicInformation = new HashSet<AcademicInformation>();
        }

        public int ExamTitleId { get; set; }
        public string ExamTitleName { get; set; }

        public ICollection<AcademicInformation> AcademicInformation { get; set; }
    }
}
