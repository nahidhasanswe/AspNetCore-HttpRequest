﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ExpenseType
    {
        public ExpenseType()
        {
            FinanceRequest = new HashSet<FinanceRequest>();
            InvoiceDetails = new HashSet<InvoiceDetails>();
        }

        public int FinanceRequestTypeId { get; set; }
        public string FinanceRequestTypeCode { get; set; }
        public string FinanceRequestTypeName { get; set; }

        public ICollection<FinanceRequest> FinanceRequest { get; set; }
        public ICollection<InvoiceDetails> InvoiceDetails { get; set; }
    }
}
