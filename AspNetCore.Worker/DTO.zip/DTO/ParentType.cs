﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ParentType
    {
        public ParentType()
        {
            Parents = new HashSet<Parents>();
        }

        public int ParentTypeId { get; set; }
        public string ParentTypeName { get; set; }

        public ICollection<Parents> Parents { get; set; }
    }
}
