﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AcademicInfoEntry
    {
        public int AcademicInfoEntryId { get; set; }
        public int StudentEntryId { get; set; }
        public int? StudentId { get; set; }
        public string StudentNumber { get; set; }
        public string LoanYear { get; set; }
        public string InstitutionName { get; set; }
        public string CourseName { get; set; }
        public string CourseDuration { get; set; }
        public decimal? LoanAmount { get; set; }
    }
}
