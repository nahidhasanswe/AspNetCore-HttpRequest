﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Country
    {
        public Country()
        {
            AcademicInformation = new HashSet<AcademicInformation>();
            Student = new HashSet<Student>();
        }

        public string CountryCode { get; set; }
        public string CountryName { get; set; }

        public ICollection<AcademicInformation> AcademicInformation { get; set; }
        public ICollection<Student> Student { get; set; }
    }
}
