﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentTerm
    {
        public int PaymentTermsId { get; set; }
        public string PaymentTerms { get; set; }
        public int? Category { get; set; }
        public int? Type { get; set; }
    }
}
