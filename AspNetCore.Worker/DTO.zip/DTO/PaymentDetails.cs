﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentDetails
    {
        public int PaymentDetailId { get; set; }
        public int PaymentInfoId { get; set; }
        public int ExpenceTypeId { get; set; }
        public int? AccountId { get; set; }
        public decimal? Amount { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string PaymentCheque { get; set; }
        public short? Status { get; set; }

        public PaymentInfo PaymentInfo { get; set; }
    }
}
