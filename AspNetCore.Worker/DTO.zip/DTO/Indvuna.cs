﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Indvuna
    {
        public int IndvunaId { get; set; }
        public int ChiefCode { get; set; }
        public int IndvunaCode { get; set; }
        public string IndvunaName { get; set; }

        public Chief ChiefCodeNavigation { get; set; }
    }
}
