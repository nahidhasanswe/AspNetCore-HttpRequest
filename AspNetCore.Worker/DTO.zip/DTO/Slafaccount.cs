﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Slafaccount
    {
        public int SlafaccountId { get; set; }
        public string Description { get; set; }
        public string AccountMasterCode { get; set; }
        public decimal? Amount { get; set; }
        public short? SlafaccountStatus { get; set; }
        public int? AccountTypeId { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApproveDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
    }
}
