﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentMode
    {
        public int PaymentModeId { get; set; }
        public string PaymentModeName { get; set; }
    }
}
