﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PayeeType
    {
        public PayeeType()
        {
            LoanAccount = new HashSet<LoanAccount>();
        }

        public int PayeeTypeId { get; set; }
        public string Description { get; set; }

        public ICollection<LoanAccount> LoanAccount { get; set; }
    }
}
