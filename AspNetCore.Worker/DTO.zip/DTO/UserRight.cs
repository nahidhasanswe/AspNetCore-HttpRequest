﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class UserRight
    {
        public UserRight()
        {
            Users = new HashSet<Users>();
        }

        public int AccessRight { get; set; }
        public string RightName { get; set; }
        public string RightDescription { get; set; }
        public string UserPermissionData { get; set; }

        public ICollection<Users> Users { get; set; }
    }
}
