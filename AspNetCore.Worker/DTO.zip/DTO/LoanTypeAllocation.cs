﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LoanTypeAllocation
    {
        public LoanTypeAllocation()
        {
            PriorityAreaAllocation = new HashSet<PriorityAreaAllocation>();
        }

        public int LoanTypeAllocationId { get; set; }
        public int BudgetAllocationId { get; set; }
        public int LoanTypeId { get; set; }
        public decimal PercentageAllocated { get; set; }
        public decimal? Amount { get; set; }
        public int? LoanAreaId { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public byte? LoanCategoryId { get; set; }

        public BudgetAllocation BudgetAllocation { get; set; }
        public LoanType LoanType { get; set; }
        public ICollection<PriorityAreaAllocation> PriorityAreaAllocation { get; set; }
    }
}
