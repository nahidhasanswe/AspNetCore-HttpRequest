﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Employer
    {
        public int EmployerId { get; set; }
        public string EmployerCode { get; set; }
        public string EmployerName { get; set; }
        public string BusinessAddress { get; set; }
        public string PostalAddress { get; set; }
        public string PostCode { get; set; }
        public string Telephone { get; set; }
        public string CellPhone { get; set; }
        public string EmailAddress { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
    }
}
