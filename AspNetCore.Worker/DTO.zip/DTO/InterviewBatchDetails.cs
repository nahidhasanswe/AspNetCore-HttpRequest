﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InterviewBatchDetails
    {
        public int InterviewBatchDetailId { get; set; }
        public int? InterviewBatchId { get; set; }
        public int ShortListAppsId { get; set; }
        public int? ApplicationId { get; set; }
        public string Comments { get; set; }

        public InterviewBatch InterviewBatch { get; set; }
        public InterviewBatchDetails InterviewBatchDetail { get; set; }
        public ShortListedApplication ShortListApps { get; set; }
        public InterviewBatchDetails InverseInterviewBatchDetail { get; set; }
    }
}
