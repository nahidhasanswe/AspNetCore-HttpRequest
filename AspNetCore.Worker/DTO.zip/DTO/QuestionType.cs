﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class QuestionType
    {
        public QuestionType()
        {
            Question = new HashSet<Question>();
        }

        public int QuestionTypeId { get; set; }
        public string QuestonTypeDescription { get; set; }

        public ICollection<Question> Question { get; set; }
    }
}
