﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AllowanceDetails
    {
        public int AllowanceDetailsId { get; set; }
        public int? AllowanceMasterId { get; set; }
        public int? ApplicationId { get; set; }
        public int? StudentId { get; set; }
        public bool? IsProcessed { get; set; }
        public short? AllowanceDetailsStatus { get; set; }

        public AllowanceMaster AllowanceMaster { get; set; }
    }
}
