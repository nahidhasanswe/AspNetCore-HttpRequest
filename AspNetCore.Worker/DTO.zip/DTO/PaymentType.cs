﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentType
    {
        public int PaymentTypeId { get; set; }
        public string Description { get; set; }
    }
}
