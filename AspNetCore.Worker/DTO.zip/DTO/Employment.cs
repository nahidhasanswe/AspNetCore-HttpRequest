﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Employment
    {
        public int EmploymentId { get; set; }
        public int? EmployerId { get; set; }
        public int? StudentId { get; set; }
        public int? EmploymentStatusId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public byte? Status { get; set; }
        public decimal? MonthlyDeductionAmount { get; set; }
    }
}
