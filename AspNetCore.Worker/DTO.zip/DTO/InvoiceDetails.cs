﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InvoiceDetails
    {
        public int InvoiceDetailId { get; set; }
        public int InvoiceId { get; set; }
        public int StudentId { get; set; }
        public int CourseId { get; set; }
        public int ExpenseId { get; set; }
        public decimal? Amount { get; set; }
        public string StudyYear { get; set; }
        public string AcademicYear { get; set; }

        public Course Course { get; set; }
        public ExpenseType Expense { get; set; }
        public InvoiceRegister Invoice { get; set; }
        public Student Student { get; set; }
    }
}
