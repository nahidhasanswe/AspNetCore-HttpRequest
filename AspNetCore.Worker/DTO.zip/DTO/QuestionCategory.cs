﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class QuestionCategory
    {
        public QuestionCategory()
        {
            Question = new HashSet<Question>();
        }

        public int QuestionCategoryId { get; set; }
        public string QuestionCategoryName { get; set; }

        public ICollection<Question> Question { get; set; }
    }
}
