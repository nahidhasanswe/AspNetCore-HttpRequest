﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ResourceFile
    {
        public ResourceFile()
        {
            InstitutionAccount = new HashSet<InstitutionAccount>();
        }

        public int ResourceId { get; set; }
        public string ResourceFileTitle { get; set; }
        public string ResourceFileName { get; set; }
        public byte[] ResourceFile1 { get; set; }
        public string ResourceDescription { get; set; }
        public string ResourceFileType { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public int? Status { get; set; }

        public ICollection<InstitutionAccount> InstitutionAccount { get; set; }
    }
}
