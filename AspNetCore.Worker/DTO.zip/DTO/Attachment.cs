﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Attachment
    {
        public int AttachmentId { get; set; }
        public int StudentId { get; set; }
        public string AttachmentDescription { get; set; }
        public int AttachmentTypeId { get; set; }
        public byte[] AttachmentFile { get; set; }
        public DateTime? DateOfAttachment { get; set; }

        public AttachmentType AttachmentType { get; set; }
        public Student Student { get; set; }
    }
}
