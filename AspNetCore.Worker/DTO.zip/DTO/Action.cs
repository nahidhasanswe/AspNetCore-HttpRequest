﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Action
    {
        public Action()
        {
            LogMain = new HashSet<LogMain>();
        }

        public int ActionId { get; set; }
        public int? FormId { get; set; }
        public string ButtonName { get; set; }
        public string ActionName { get; set; }
        public int? Status { get; set; }

        public ICollection<LogMain> LogMain { get; set; }
    }
}
