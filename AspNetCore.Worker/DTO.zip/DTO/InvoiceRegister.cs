﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InvoiceRegister
    {
        public InvoiceRegister()
        {
            InvoiceDetails = new HashSet<InvoiceDetails>();
        }

        public int InvoiceId { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public int InstitutionId { get; set; }
        public string InvoiceYear { get; set; }
        public decimal? InvoiceTotal { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public string InvoiceNumber { get; set; }
        public string PurchaseNo { get; set; }
        public int? TransferType { get; set; }
        public int? PaymentMode { get; set; }
        public string DeliveryNote { get; set; }
        public short? InvoiceType { get; set; }

        public Institution Institution { get; set; }
        public ICollection<InvoiceDetails> InvoiceDetails { get; set; }
    }
}
