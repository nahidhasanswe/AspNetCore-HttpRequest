﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class UserTypes
    {
        public UserTypes()
        {
            Users = new HashSet<Users>();
        }

        public int UserTypeId { get; set; }
        public string Description { get; set; }

        public ICollection<Users> Users { get; set; }
    }
}
