﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InterviewResponseDetails
    {
        public int InterviewRespDetailsId { get; set; }
        public int InterviewResponseId { get; set; }
        public int InterviewerId { get; set; }
        public int? QuestionId { get; set; }
        public string QuestionResponse { get; set; }
        public decimal Score { get; set; }
        public byte? Status { get; set; }
    }
}
