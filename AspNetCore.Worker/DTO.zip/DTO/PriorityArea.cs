﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PriorityArea
    {
        public PriorityArea()
        {
            PriorityAreaAllocation = new HashSet<PriorityAreaAllocation>();
        }

        public int PriorityAreaId { get; set; }
        public string PriorityAreaDescription { get; set; }
        public byte PriorityType { get; set; }

        public ICollection<PriorityAreaAllocation> PriorityAreaAllocation { get; set; }
    }
}
