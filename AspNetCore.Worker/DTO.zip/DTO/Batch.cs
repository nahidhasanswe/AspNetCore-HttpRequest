﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Batch
    {
        public int BatchId { get; set; }
        public string BatchTitle { get; set; }
        public string BatchSource { get; set; }
        public int NoOfApplication { get; set; }
        public string Comment { get; set; }
        public string ReviewedBy { get; set; }
        public DateTime? ReviewDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public string LoanYear { get; set; }
    }
}
