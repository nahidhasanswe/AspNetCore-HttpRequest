﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class SupplierAccount
    {
        public int SupplierAccountId { get; set; }
        public int SupplierId { get; set; }
        public int ContactPersonId { get; set; }
        public string AccountNo { get; set; }
        public string BankAccountNo { get; set; }
        public string BranchCode { get; set; }
        public string BankId { get; set; }
        public string Country { get; set; }
        public bool? IsApproved { get; set; }
        public bool? IsEnable { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public string SwiftCode { get; set; }
        public string AccountName { get; set; }
        public string BankAddress { get; set; }
        public string LoanNumber { get; set; }
        public int? PayeeTypeId { get; set; }
        public string BankName { get; set; }
        public decimal? OpeningBalance { get; set; }

        public ContactPerson ContactPerson { get; set; }
        public Supplier Supplier { get; set; }
    }
}
