﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Form
    {
        public int FormId { get; set; }
        public int? ModuleId { get; set; }
        public string FormName { get; set; }
        public string FormDescription { get; set; }
        public int? Status { get; set; }
    }
}
