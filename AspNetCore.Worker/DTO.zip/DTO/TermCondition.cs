﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class TermCondition
    {
        public int TermConditionId { get; set; }
        public int? AccountId { get; set; }
        public int? InstitutionAccountId { get; set; }
        public int? SupplierAccountId { get; set; }
        public int? PaymentTerms { get; set; }
        public int? RepaymentTerms { get; set; }
        public int? InstitutionTerm { get; set; }
        public bool IsInvoiceSent { get; set; }
        public int? SupplierTerms { get; set; }
        public string BankAddress { get; set; }
        public string CountryCode { get; set; }
        public DateTime? AccountCreationDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public string SwiftCode { get; set; }
        public bool? IsApproved { get; set; }
        public bool? IsEnable { get; set; }
        public string AccountName { get; set; }
    }
}
