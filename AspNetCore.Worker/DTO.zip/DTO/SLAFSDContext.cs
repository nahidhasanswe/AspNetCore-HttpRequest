﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class SLAFSDContext : DbContext
    {
        public SLAFSDContext()
        {
        }

        public SLAFSDContext(DbContextOptions<SLAFSDContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AcademicInfoEntry> AcademicInfoEntry { get; set; }
        public virtual DbSet<AcademicInformation> AcademicInformation { get; set; }
        public virtual DbSet<AcademicResult> AcademicResult { get; set; }
        public virtual DbSet<AccademicStatus> AccademicStatus { get; set; }
        public virtual DbSet<AccessRight> AccessRight { get; set; }
        public virtual DbSet<Action> Action { get; set; }
        public virtual DbSet<ActualTransaction> ActualTransaction { get; set; }
        public virtual DbSet<AllowanceDetails> AllowanceDetails { get; set; }
        public virtual DbSet<AllowanceGroup> AllowanceGroup { get; set; }
        public virtual DbSet<AllowanceGroupDetails> AllowanceGroupDetails { get; set; }
        public virtual DbSet<AllowanceMaster> AllowanceMaster { get; set; }
        public virtual DbSet<AllowancePayment> AllowancePayment { get; set; }
        public virtual DbSet<ApplicationSession> ApplicationSession { get; set; }
        public virtual DbSet<AppliedCourse> AppliedCourse { get; set; }
        public virtual DbSet<Attachment> Attachment { get; set; }
        public virtual DbSet<AttachmentType> AttachmentType { get; set; }
        public virtual DbSet<AverageCost> AverageCost { get; set; }
        public virtual DbSet<Award> Award { get; set; }
        public virtual DbSet<AwardList> AwardList { get; set; }
        public virtual DbSet<Bank> Bank { get; set; }
        public virtual DbSet<BankTransaction> BankTransaction { get; set; }
        public virtual DbSet<BankTransactionDetail> BankTransactionDetail { get; set; }
        public virtual DbSet<BankTransactionSubDetail> BankTransactionSubDetail { get; set; }
        public virtual DbSet<Batch> Batch { get; set; }
        public virtual DbSet<BatchPaymentSummary> BatchPaymentSummary { get; set; }
        public virtual DbSet<BudgetAllocation> BudgetAllocation { get; set; }
        public virtual DbSet<Chief> Chief { get; set; }
        public virtual DbSet<ContactPerson> ContactPerson { get; set; }
        public virtual DbSet<Country> Country { get; set; }
        public virtual DbSet<Course> Course { get; set; }
        public virtual DbSet<DocumentContent> DocumentContent { get; set; }
        public virtual DbSet<EmployeeRepayAllocation> EmployeeRepayAllocation { get; set; }
        public virtual DbSet<Employer> Employer { get; set; }
        public virtual DbSet<Employment> Employment { get; set; }
        public virtual DbSet<EmploymentStatus> EmploymentStatus { get; set; }
        public virtual DbSet<ExamTitle> ExamTitle { get; set; }
        public virtual DbSet<ExistingCap> ExistingCap { get; set; }
        public virtual DbSet<ExpenseAmount> ExpenseAmount { get; set; }
        public virtual DbSet<ExpenseType> ExpenseType { get; set; }
        public virtual DbSet<FinanceRequest> FinanceRequest { get; set; }
        public virtual DbSet<FinanceRequestType> FinanceRequestType { get; set; }
        public virtual DbSet<Folder> Folder { get; set; }
        public virtual DbSet<Form> Form { get; set; }
        public virtual DbSet<FundingSource> FundingSource { get; set; }
        public virtual DbSet<Grading> Grading { get; set; }
        public virtual DbSet<IncomeType> IncomeType { get; set; }
        public virtual DbSet<Industry> Industry { get; set; }
        public virtual DbSet<Indvuna> Indvuna { get; set; }
        public virtual DbSet<InstituteCourseMapping> InstituteCourseMapping { get; set; }
        public virtual DbSet<Institution> Institution { get; set; }
        public virtual DbSet<InstitutionAccount> InstitutionAccount { get; set; }
        public virtual DbSet<InstitutionalCost> InstitutionalCost { get; set; }
        public virtual DbSet<InstitutionPaymentMapping> InstitutionPaymentMapping { get; set; }
        public virtual DbSet<InstitutionSettings> InstitutionSettings { get; set; }
        public virtual DbSet<InstitutionUploadedResult> InstitutionUploadedResult { get; set; }
        public virtual DbSet<InterestRate> InterestRate { get; set; }
        public virtual DbSet<Interview> Interview { get; set; }
        public virtual DbSet<InterviewBatch> InterviewBatch { get; set; }
        public virtual DbSet<InterviewBatchDetails> InterviewBatchDetails { get; set; }
        public virtual DbSet<Interviewer> Interviewer { get; set; }
        public virtual DbSet<InterviewResponse> InterviewResponse { get; set; }
        public virtual DbSet<InterviewResponseDetails> InterviewResponseDetails { get; set; }
        public virtual DbSet<Invoice> Invoice { get; set; }
        public virtual DbSet<InvoiceDetails> InvoiceDetails { get; set; }
        public virtual DbSet<InvoiceRegister> InvoiceRegister { get; set; }
        public virtual DbSet<LaonCategory> LaonCategory { get; set; }
        public virtual DbSet<LoanAccount> LoanAccount { get; set; }
        public virtual DbSet<LoanApplication> LoanApplication { get; set; }
        public virtual DbSet<LoanType> LoanType { get; set; }
        public virtual DbSet<LoanTypeAllocation> LoanTypeAllocation { get; set; }
        public virtual DbSet<LoanYearSettings> LoanYearSettings { get; set; }
        public virtual DbSet<LoginInfo> LoginInfo { get; set; }
        public virtual DbSet<LogMain> LogMain { get; set; }
        public virtual DbSet<LogType> LogType { get; set; }
        public virtual DbSet<Message> Message { get; set; }
        public virtual DbSet<MessageDetail> MessageDetail { get; set; }
        public virtual DbSet<Ministry> Ministry { get; set; }
        public virtual DbSet<Module> Module { get; set; }
        public virtual DbSet<Nationality> Nationality { get; set; }
        public virtual DbSet<News> News { get; set; }
        public virtual DbSet<OngoingBudget> OngoingBudget { get; set; }
        public virtual DbSet<Parents> Parents { get; set; }
        public virtual DbSet<ParentStatus> ParentStatus { get; set; }
        public virtual DbSet<ParentType> ParentType { get; set; }
        public virtual DbSet<PayeeType> PayeeType { get; set; }
        public virtual DbSet<PaymentBatch> PaymentBatch { get; set; }
        public virtual DbSet<PaymentBatchDetail> PaymentBatchDetail { get; set; }
        public virtual DbSet<PaymentBatchDetailHeads> PaymentBatchDetailHeads { get; set; }
        public virtual DbSet<PaymentBatchSummary> PaymentBatchSummary { get; set; }
        public virtual DbSet<PaymentDetails> PaymentDetails { get; set; }
        public virtual DbSet<PaymentFile> PaymentFile { get; set; }
        public virtual DbSet<PaymentInfo> PaymentInfo { get; set; }
        public virtual DbSet<PaymentMode> PaymentMode { get; set; }
        public virtual DbSet<PaymentTerm> PaymentTerm { get; set; }
        public virtual DbSet<PaymentType> PaymentType { get; set; }
        public virtual DbSet<PointOfPay> PointOfPay { get; set; }
        public virtual DbSet<Policy> Policy { get; set; }
        public virtual DbSet<PriorityArea> PriorityArea { get; set; }
        public virtual DbSet<PriorityAreaAllocation> PriorityAreaAllocation { get; set; }
        public virtual DbSet<PurchaseOrder> PurchaseOrder { get; set; }
        public virtual DbSet<PurchaseOrderDetail> PurchaseOrderDetail { get; set; }
        public virtual DbSet<Question> Question { get; set; }
        public virtual DbSet<QuestionCategory> QuestionCategory { get; set; }
        public virtual DbSet<QuestionManager> QuestionManager { get; set; }
        public virtual DbSet<QuestionOption> QuestionOption { get; set; }
        public virtual DbSet<QuestionType> QuestionType { get; set; }
        public virtual DbSet<References> References { get; set; }
        public virtual DbSet<Region> Region { get; set; }
        public virtual DbSet<RepaymentDetail> RepaymentDetail { get; set; }
        public virtual DbSet<RepaymentRegister> RepaymentRegister { get; set; }
        public virtual DbSet<RepaymentSource> RepaymentSource { get; set; }
        public virtual DbSet<ReportingStatus> ReportingStatus { get; set; }
        public virtual DbSet<ReportingType> ReportingType { get; set; }
        public virtual DbSet<ReportingTypeValues> ReportingTypeValues { get; set; }
        public virtual DbSet<ResourceFile> ResourceFile { get; set; }
        public virtual DbSet<Selection> Selection { get; set; }
        public virtual DbSet<ShortListedApplication> ShortListedApplication { get; set; }
        public virtual DbSet<Slafaccount> Slafaccount { get; set; }
        public virtual DbSet<SocioEconomic> SocioEconomic { get; set; }
        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<StudentAttachmentRelation> StudentAttachmentRelation { get; set; }
        public virtual DbSet<StudentEntry> StudentEntry { get; set; }
        public virtual DbSet<Subject> Subject { get; set; }
        public virtual DbSet<Supplier> Supplier { get; set; }
        public virtual DbSet<SupplierAccount> SupplierAccount { get; set; }
        public virtual DbSet<TempNationalId> TempNationalId { get; set; }
        public virtual DbSet<TermCondition> TermCondition { get; set; }
        public virtual DbSet<Transaction> Transaction { get; set; }
        public virtual DbSet<TransferType> TransferType { get; set; }
        public virtual DbSet<UserRight> UserRight { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<UserTypes> UserTypes { get; set; }
        public virtual DbSet<Voucher> Voucher { get; set; }
        public virtual DbSet<VoucherDetail> VoucherDetail { get; set; }
        public virtual DbSet<VoucherType> VoucherType { get; set; }

        // Unable to generate entity type for table 'dbo.CappingAmountFromFile'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.EmployerFromExcel'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.AccountChangedHistory'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.InstitutionUsers'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=10.200.10.151;Database=SLAFSD;Persist Security Info=True;User ID=sa;Password=abcd123!");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AcademicInfoEntry>(entity =>
            {
                entity.Property(e => e.AcademicInfoEntryId).HasColumnName("AcademicInfoEntryID");

                entity.Property(e => e.CourseDuration).HasMaxLength(10);

                entity.Property(e => e.CourseName).HasMaxLength(250);

                entity.Property(e => e.InstitutionName).HasMaxLength(100);

                entity.Property(e => e.LoanYear).HasMaxLength(10);

                entity.Property(e => e.StudentEntryId).HasColumnName("StudentEntryID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.StudentNumber).HasMaxLength(20);
            });

            modelBuilder.Entity<AcademicInformation>(entity =>
            {
                entity.HasKey(e => e.AcademicInfoId);

                entity.Property(e => e.AcademicInfoId).HasColumnName("AcademicInfoID");

                entity.Property(e => e.Address).HasMaxLength(70);

                entity.Property(e => e.CountryCode)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.ExamTitleId).HasColumnName("ExamTitleID");

                entity.Property(e => e.FinishDate).HasColumnType("date");

                entity.Property(e => e.FundingSourceId).HasColumnName("FundingSourceID");

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OtherExamTitle).HasMaxLength(50);

                entity.Property(e => e.SchoolName).HasMaxLength(70);

                entity.Property(e => e.StartDate).HasColumnType("date");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.HasOne(d => d.CountryCodeNavigation)
                    .WithMany(p => p.AcademicInformation)
                    .HasForeignKey(d => d.CountryCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AcademicInformation_Country");

                entity.HasOne(d => d.ExamTitle)
                    .WithMany(p => p.AcademicInformation)
                    .HasForeignKey(d => d.ExamTitleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AcademicInformation_ExamTitle");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.AcademicInformation)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AcademicInformation_Student");
            });

            modelBuilder.Entity<AcademicResult>(entity =>
            {
                entity.HasKey(e => e.ResultId);

                entity.Property(e => e.ResultId).HasColumnName("ResultID");

                entity.Property(e => e.AcademicInfoId).HasColumnName("AcademicInfoID");

                entity.Property(e => e.Aps).HasColumnName("APS");

                entity.Property(e => e.ExamCenterNo).HasMaxLength(20);

                entity.Property(e => e.ExamYear).HasMaxLength(4);

                entity.Property(e => e.Score).HasMaxLength(10);

                entity.Property(e => e.StudentExamNo).HasMaxLength(20);

                entity.Property(e => e.SubjectId).HasColumnName("SubjectID");

                entity.HasOne(d => d.AcademicInfo)
                    .WithMany(p => p.AcademicResult)
                    .HasForeignKey(d => d.AcademicInfoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AcademicResult_AcademicInformation");

                entity.HasOne(d => d.Subject)
                    .WithMany(p => p.AcademicResult)
                    .HasForeignKey(d => d.SubjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AcademicResult_Subject");
            });

            modelBuilder.Entity<AccademicStatus>(entity =>
            {
                entity.HasKey(e => e.Armid);

                entity.Property(e => e.Armid).HasColumnName("ARMID");

                entity.Property(e => e.AccStatus).HasMaxLength(50);

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApprovalComments).HasMaxLength(150);

                entity.Property(e => e.ApprovedBy).HasMaxLength(30);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.Notes).HasMaxLength(250);

                entity.Property(e => e.ReviewedBy).HasMaxLength(50);

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.AccademicStatus)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AccademicStatus_Course");

                entity.HasOne(d => d.Institution)
                    .WithMany(p => p.AccademicStatus)
                    .HasForeignKey(d => d.InstitutionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AccademicStatus_Institution");
            });

            modelBuilder.Entity<AccessRight>(entity =>
            {
                entity.Property(e => e.AccessRightId).HasColumnName("AccessRightID");

                entity.Property(e => e.AccessRightName).HasMaxLength(50);
            });

            modelBuilder.Entity<Action>(entity =>
            {
                entity.Property(e => e.ActionId).HasColumnName("ActionID");

                entity.Property(e => e.ActionName).HasMaxLength(50);

                entity.Property(e => e.ButtonName).HasMaxLength(50);

                entity.Property(e => e.FormId).HasColumnName("FormID");
            });

            modelBuilder.Entity<ActualTransaction>(entity =>
            {
                entity.HasKey(e => new { e.AccTransId, e.TransactionYear, e.Payee });

                entity.Property(e => e.AccTransId).HasColumnName("AccTransID");

                entity.Property(e => e.TransactionYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.TransactionDate).HasMaxLength(10);

                entity.HasOne(d => d.PayeeNavigation)
                    .WithMany(p => p.ActualTransaction)
                    .HasForeignKey(d => d.Payee)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ActualTransaction_LoanAccount");
            });

            modelBuilder.Entity<AllowanceDetails>(entity =>
            {
                entity.Property(e => e.AllowanceDetailsId).HasColumnName("AllowanceDetailsID");

                entity.Property(e => e.AllowanceMasterId).HasColumnName("AllowanceMasterID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.HasOne(d => d.AllowanceMaster)
                    .WithMany(p => p.AllowanceDetails)
                    .HasForeignKey(d => d.AllowanceMasterId)
                    .HasConstraintName("FK_AllowanceDetails_AllowanceMaster");
            });

            modelBuilder.Entity<AllowanceGroup>(entity =>
            {
                entity.Property(e => e.AllowanceGroupId).HasColumnName("AllowanceGroupID");

                entity.Property(e => e.CreationDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<AllowanceGroupDetails>(entity =>
            {
                entity.HasKey(e => e.AllowanceGrpDetailId);

                entity.Property(e => e.AllowanceGrpDetailId).HasColumnName("AllowanceGrpDetailID");

                entity.Property(e => e.AllowanceGroupId).HasColumnName("AllowanceGroupID");

                entity.Property(e => e.AllowanceMasterId).HasColumnName("AllowanceMasterID");

                entity.HasOne(d => d.AllowanceGroup)
                    .WithMany(p => p.AllowanceGroupDetails)
                    .HasForeignKey(d => d.AllowanceGroupId)
                    .HasConstraintName("FK_AllowanceGroupDetails_AllowanceGroup");

                entity.HasOne(d => d.AllowanceMaster)
                    .WithMany(p => p.AllowanceGroupDetails)
                    .HasForeignKey(d => d.AllowanceMasterId)
                    .HasConstraintName("FK_AllowanceGroupDetails_AllowanceMaster");
            });

            modelBuilder.Entity<AllowanceMaster>(entity =>
            {
                entity.HasKey(e => e.AllowanceId);

                entity.Property(e => e.AllowanceId).HasColumnName("AllowanceID");

                entity.Property(e => e.BatchName).HasMaxLength(200);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<AllowancePayment>(entity =>
            {
                entity.Property(e => e.AllowancePaymentId).HasColumnName("AllowancePaymentID");

                entity.Property(e => e.AllowanceGroupId).HasColumnName("AllowanceGroupID");

                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.HasOne(d => d.AllowanceGroup)
                    .WithMany(p => p.AllowancePayment)
                    .HasForeignKey(d => d.AllowanceGroupId)
                    .HasConstraintName("FK_AllowancePayment_AllowanceGroup");
            });

            modelBuilder.Entity<ApplicationSession>(entity =>
            {
                entity.Property(e => e.ApplicationSessionId).HasColumnName("ApplicationSessionID");

                entity.Property(e => e.AuthorizedBy).HasMaxLength(50);

                entity.Property(e => e.AuthorizedDate).HasColumnType("date");

                entity.Property(e => e.CaptureDate).HasColumnType("date");

                entity.Property(e => e.CapturedBy).HasMaxLength(50);

                entity.Property(e => e.EndDate).HasColumnType("date");

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(100);

                entity.Property(e => e.SessionTitle).HasMaxLength(50);

                entity.Property(e => e.StartDate).HasColumnType("date");
            });

            modelBuilder.Entity<AppliedCourse>(entity =>
            {
                entity.Property(e => e.AppliedCourseId).HasColumnName("AppliedCourseID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.CourseId).HasColumnName("CourseID");
            });

            modelBuilder.Entity<Attachment>(entity =>
            {
                entity.Property(e => e.AttachmentId).HasColumnName("AttachmentID");

                entity.Property(e => e.AttachmentDescription).HasMaxLength(70);

                entity.Property(e => e.AttachmentFile).HasColumnType("image");

                entity.Property(e => e.AttachmentTypeId).HasColumnName("AttachmentTypeID");

                entity.Property(e => e.DateOfAttachment).HasColumnType("datetime");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.HasOne(d => d.AttachmentType)
                    .WithMany(p => p.Attachment)
                    .HasForeignKey(d => d.AttachmentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Attachment_AttachmentType");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.Attachment)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Attachment_Student");
            });

            modelBuilder.Entity<AttachmentType>(entity =>
            {
                entity.Property(e => e.AttachmentTypeId).HasColumnName("AttachmentTypeID");

                entity.Property(e => e.AttachmentTypeDescription).HasMaxLength(70);
            });

            modelBuilder.Entity<AverageCost>(entity =>
            {
                entity.Property(e => e.AverageCostId).HasColumnName("AverageCostID");

                entity.Property(e => e.AverageCost1)
                    .HasColumnName("AverageCost")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.LoanAreaId).HasColumnName("LoanAreaID");

                entity.Property(e => e.LoanTypeId).HasColumnName("LoanTypeID");

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.PriorityAreaId).HasColumnName("PriorityAreaID");
            });

            modelBuilder.Entity<Award>(entity =>
            {
                entity.Property(e => e.AwardId).HasColumnName("AwardID");

                entity.Property(e => e.AwardDate).HasColumnType("datetime");

                entity.Property(e => e.AwardNotes).HasMaxLength(150);

                entity.Property(e => e.AwardYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.AwardedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<AwardList>(entity =>
            {
                entity.Property(e => e.AwardListId).HasColumnName("AwardListID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApprovedBy).HasMaxLength(30);

                entity.Property(e => e.AwardComments).HasMaxLength(100);

                entity.Property(e => e.AwardDate).HasColumnType("datetime");

                entity.Property(e => e.AwardId).HasColumnName("AwardID");

                entity.Property(e => e.AwardYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CheckSum).HasMaxLength(50);

                entity.Property(e => e.InterviewId).HasColumnName("InterviewID");

                entity.HasOne(d => d.Award)
                    .WithMany(p => p.AwardList)
                    .HasForeignKey(d => d.AwardId)
                    .HasConstraintName("FK_AwardList_Award");
            });

            modelBuilder.Entity<Bank>(entity =>
            {
                entity.Property(e => e.BankId).HasColumnName("BankID");

                entity.Property(e => e.BankName).HasMaxLength(50);

                entity.Property(e => e.CountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<BankTransaction>(entity =>
            {
                entity.Property(e => e.BankTransactionId).HasColumnName("BankTransactionID");

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.ComputerNumber).HasMaxLength(50);

                entity.Property(e => e.CreatedBy).HasMaxLength(30);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.EmployerCode).HasMaxLength(50);

                entity.Property(e => e.ExpectedAmount).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.Reference).HasMaxLength(120);

                entity.Property(e => e.TransactionDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedBy).HasMaxLength(30);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.UploadMessage).HasMaxLength(200);
            });

            modelBuilder.Entity<BankTransactionDetail>(entity =>
            {
                entity.Property(e => e.BankTransactionDetailId).HasColumnName("BankTransactionDetailID");

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.BankTransactionId).HasColumnName("BankTransactionID");

                entity.Property(e => e.Reference)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TransactionDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<BankTransactionSubDetail>(entity =>
            {
                entity.Property(e => e.BankTransactionSubDetailId).HasColumnName("BankTransactionSubDetailID");

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.BankTransactionDetailId).HasColumnName("BankTransactionDetailID");

                entity.Property(e => e.ComputerNo)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Reference)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Batch>(entity =>
            {
                entity.Property(e => e.BatchId).HasColumnName("BatchID");

                entity.Property(e => e.BatchSource)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BatchTitle).HasMaxLength(50);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.Comment)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ReviewDate).HasColumnType("datetime");

                entity.Property(e => e.ReviewedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<BatchPaymentSummary>(entity =>
            {
                entity.Property(e => e.BatchPaymentSummaryId).HasColumnName("BatchPaymentSummaryID");

                entity.Property(e => e.BatchPaymentId).HasColumnName("BatchPaymentID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.HeadCode).HasMaxLength(30);

                entity.Property(e => e.InvoiceNo).HasMaxLength(20);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<BudgetAllocation>(entity =>
            {
                entity.Property(e => e.BudgetAllocationId).HasColumnName("BudgetAllocationID");

                entity.Property(e => e.BudgetAllocationYear)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<Chief>(entity =>
            {
                entity.HasKey(e => e.ChiefCode);

                entity.Property(e => e.ChiefCode).ValueGeneratedNever();

                entity.Property(e => e.ChiefName).HasMaxLength(70);
            });

            modelBuilder.Entity<ContactPerson>(entity =>
            {
                entity.Property(e => e.ContactPersonId)
                    .HasColumnName("ContactPersonID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Address).HasMaxLength(100);

                entity.Property(e => e.ContactCode).HasMaxLength(50);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Designation).HasMaxLength(50);

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Phone).HasMaxLength(50);

                entity.Property(e => e.Region).HasMaxLength(50);

                entity.HasOne(d => d.ContactPersonNavigation)
                    .WithOne(p => p.ContactPerson)
                    .HasForeignKey<ContactPerson>(d => d.ContactPersonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ContactPerson_InstitutionAccount");
            });

            modelBuilder.Entity<Country>(entity =>
            {
                entity.HasKey(e => e.CountryCode);

                entity.Property(e => e.CountryCode)
                    .HasMaxLength(3)
                    .ValueGeneratedNever();

                entity.Property(e => e.CountryName).HasMaxLength(50);
            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.CourseCode).HasMaxLength(10);

                entity.Property(e => e.CourseName)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.PriorityAreaId).HasColumnName("PriorityAreaID");
            });

            modelBuilder.Entity<DocumentContent>(entity =>
            {
                entity.HasKey(e => e.DocumentId);

                entity.Property(e => e.DocumentId).HasColumnName("DocumentID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.Content)
                    .IsRequired()
                    .HasColumnType("image");

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ReferenceId).HasColumnName("ReferenceID");

                entity.Property(e => e.TypeId).HasColumnName("TypeID");
            });

            modelBuilder.Entity<EmployeeRepayAllocation>(entity =>
            {
                entity.Property(e => e.EmployeeRepayAllocationId).HasColumnName("EmployeeRepayAllocationID");

                entity.Property(e => e.ComputerNo).HasMaxLength(50);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.EmployerCode).HasMaxLength(20);

                entity.Property(e => e.EmployerId).HasColumnName("EmployerID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<Employer>(entity =>
            {
                entity.Property(e => e.EmployerId).HasColumnName("EmployerID");

                entity.Property(e => e.BusinessAddress).HasMaxLength(200);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CellPhone).HasMaxLength(20);

                entity.Property(e => e.EmailAddress).HasMaxLength(70);

                entity.Property(e => e.EmployerCode).HasMaxLength(20);

                entity.Property(e => e.EmployerName).HasMaxLength(70);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PostCode).HasMaxLength(10);

                entity.Property(e => e.PostalAddress).HasMaxLength(200);

                entity.Property(e => e.Telephone).HasMaxLength(20);
            });

            modelBuilder.Entity<Employment>(entity =>
            {
                entity.Property(e => e.EmploymentId).HasColumnName("EmploymentID");

                entity.Property(e => e.CreatedBy).HasMaxLength(30);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.EmployerId).HasColumnName("EmployerID");

                entity.Property(e => e.EmploymentStatusId).HasColumnName("EmploymentStatusID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.UpdatedBy).HasMaxLength(30);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<EmploymentStatus>(entity =>
            {
                entity.Property(e => e.EmploymentStatusId).HasColumnName("EmploymentStatusID");

                entity.Property(e => e.EmploymentStatusName).HasMaxLength(250);
            });

            modelBuilder.Entity<ExamTitle>(entity =>
            {
                entity.Property(e => e.ExamTitleId).HasColumnName("ExamTitleID");

                entity.Property(e => e.ExamTitleName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ExistingCap>(entity =>
            {
                entity.Property(e => e.ExistingCapId).HasColumnName("ExistingCapID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.Year).HasMaxLength(4);
            });

            modelBuilder.Entity<ExpenseAmount>(entity =>
            {
                entity.Property(e => e.ExpenseAmountId).HasColumnName("ExpenseAmountID");

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.ExpenseAmount1).HasColumnName("ExpenseAmount");

                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.LoanAreaId).HasColumnName("LoanAreaID");

                entity.Property(e => e.LoanCategoryId).HasColumnName("LoanCategoryID");

                entity.Property(e => e.LoanTypeId).HasColumnName("LoanTypeID");

                entity.Property(e => e.LoanYear)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ExpenseType>(entity =>
            {
                entity.HasKey(e => e.FinanceRequestTypeId);

                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.Property(e => e.FinanceRequestTypeCode).HasMaxLength(10);

                entity.Property(e => e.FinanceRequestTypeName)
                    .IsRequired()
                    .HasMaxLength(250);
            });

            modelBuilder.Entity<FinanceRequest>(entity =>
            {
                entity.HasKey(e => e.FinanceId);

                entity.Property(e => e.FinanceId).HasColumnName("FinanceID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.HasOne(d => d.FinanceRequestType)
                    .WithMany(p => p.FinanceRequest)
                    .HasForeignKey(d => d.FinanceRequestTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FinanceRequest_FinanceRequestType");
            });

            modelBuilder.Entity<FinanceRequestType>(entity =>
            {
                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.Property(e => e.FinanceRequestTypeName).HasMaxLength(50);
            });

            modelBuilder.Entity<Folder>(entity =>
            {
                entity.Property(e => e.FolderId).HasColumnName("FolderID");

                entity.Property(e => e.AcademicYear)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Barcode).HasMaxLength(15);

                entity.Property(e => e.Description).HasMaxLength(150);

                entity.Property(e => e.FolderNo)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.Location).HasMaxLength(100);

                entity.Property(e => e.ReferenceNo).HasMaxLength(15);

                entity.Property(e => e.RoomNo).HasMaxLength(50);

                entity.Property(e => e.RowNo).HasMaxLength(50);

                entity.Property(e => e.SelfNo).HasMaxLength(50);
            });

            modelBuilder.Entity<Form>(entity =>
            {
                entity.Property(e => e.FormId).HasColumnName("FormID");

                entity.Property(e => e.FormDescription).HasMaxLength(100);

                entity.Property(e => e.FormName).HasMaxLength(50);

                entity.Property(e => e.ModuleId).HasColumnName("ModuleID");
            });

            modelBuilder.Entity<FundingSource>(entity =>
            {
                entity.Property(e => e.FundingSourceId).HasColumnName("FundingSourceID");

                entity.Property(e => e.Description).HasMaxLength(50);
            });

            modelBuilder.Entity<Grading>(entity =>
            {
                entity.HasKey(e => e.GradeId);

                entity.Property(e => e.GradeId).HasColumnName("GradeID");

                entity.Property(e => e.Aps).HasColumnName("APS");

                entity.Property(e => e.ExamTitleId).HasColumnName("ExamTitleID");

                entity.Property(e => e.Grade).HasMaxLength(10);
            });

            modelBuilder.Entity<IncomeType>(entity =>
            {
                entity.Property(e => e.IncomeTypeId)
                    .HasColumnName("IncomeTypeID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Name).HasMaxLength(50);
            });

            modelBuilder.Entity<Industry>(entity =>
            {
                entity.Property(e => e.IndustryId).HasColumnName("IndustryID");

                entity.Property(e => e.IndustryName).HasMaxLength(250);
            });

            modelBuilder.Entity<Indvuna>(entity =>
            {
                entity.Property(e => e.IndvunaId).HasColumnName("IndvunaID");

                entity.Property(e => e.IndvunaName).HasMaxLength(50);

                entity.HasOne(d => d.ChiefCodeNavigation)
                    .WithMany(p => p.Indvuna)
                    .HasForeignKey(d => d.ChiefCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Indvuna_Chief");
            });

            modelBuilder.Entity<InstituteCourseMapping>(entity =>
            {
                entity.Property(e => e.InstituteCourseMappingId).HasColumnName("InstituteCourseMappingID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(50);

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);
            });

            modelBuilder.Entity<Institution>(entity =>
            {
                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.BusinessAddress).HasMaxLength(200);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CellPhone).HasMaxLength(20);

                entity.Property(e => e.CountryCode).HasMaxLength(3);

                entity.Property(e => e.EmailAddress).HasMaxLength(70);

                entity.Property(e => e.InstitutionCode)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.InstitutionName).HasMaxLength(100);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PostCode).HasMaxLength(10);

                entity.Property(e => e.PostalAddress).HasMaxLength(200);

                entity.Property(e => e.Telephone).HasMaxLength(20);
            });

            modelBuilder.Entity<InstitutionAccount>(entity =>
            {
                entity.Property(e => e.InstitutionAccountId).HasColumnName("InstitutionAccountID");

                entity.Property(e => e.AccountName).HasMaxLength(50);

                entity.Property(e => e.AccountNo).HasMaxLength(20);

                entity.Property(e => e.BankAccountNo).HasMaxLength(50);

                entity.Property(e => e.BankAddress).HasMaxLength(150);

                entity.Property(e => e.BankId)
                    .HasColumnName("BankID")
                    .HasMaxLength(50);

                entity.Property(e => e.BankName).HasMaxLength(150);

                entity.Property(e => e.BranchCode).HasMaxLength(50);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ContactPersonId).HasColumnName("ContactPersonID");

                entity.Property(e => e.Country)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.LoanNumber).HasMaxLength(15);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PayeeTypeId).HasColumnName("PayeeTypeID");

                entity.Property(e => e.ResourceId).HasColumnName("ResourceID");

                entity.Property(e => e.SwiftCode).HasMaxLength(20);

                entity.HasOne(d => d.Resource)
                    .WithMany(p => p.InstitutionAccount)
                    .HasForeignKey(d => d.ResourceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InstitutionAccount_ResourceFile");
            });

            modelBuilder.Entity<InstitutionalCost>(entity =>
            {
                entity.HasKey(e => e.InstitutionCostId);

                entity.Property(e => e.InstitutionCostId)
                    .HasColumnName("InstitutionCostID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CaptuedBy).HasMaxLength(50);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.ExpenseId).HasColumnName("ExpenseID");

                entity.Property(e => e.FinYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.HasOne(d => d.Institution)
                    .WithMany(p => p.InstitutionalCost)
                    .HasForeignKey(d => d.InstitutionId)
                    .HasConstraintName("FK_InstitutionalCost_Institution");
            });

            modelBuilder.Entity<InstitutionPaymentMapping>(entity =>
            {
                entity.Property(e => e.InstitutionPaymentMappingId).HasColumnName("InstitutionPaymentMappingID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<InstitutionSettings>(entity =>
            {
                entity.Property(e => e.InstitutionSettingsId).HasColumnName("InstitutionSettingsID");

                entity.Property(e => e.ApplicationSessionId).HasColumnName("ApplicationSessionID");

                entity.Property(e => e.AuthorizedBy).HasMaxLength(30);

                entity.Property(e => e.AuthorizedDate).HasColumnType("datetime");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.StartDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<InstitutionUploadedResult>(entity =>
            {
                entity.Property(e => e.InstitutionUploadedResultId).HasColumnName("InstitutionUploadedResultID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ResultTitle).HasMaxLength(200);
            });

            modelBuilder.Entity<InterestRate>(entity =>
            {
                entity.HasKey(e => e.InterestId);

                entity.Property(e => e.InterestId).HasColumnName("InterestID");

                entity.Property(e => e.AuthorizedBy).HasMaxLength(30);

                entity.Property(e => e.AuthorizedDate).HasColumnType("datetime");

                entity.Property(e => e.InterestRate1).HasColumnName("InterestRate");

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Interview>(entity =>
            {
                entity.Property(e => e.InterviewId).HasColumnName("InterviewID");

                entity.Property(e => e.ApprovalDate).HasColumnType("datetime");

                entity.Property(e => e.ApprovedBy).HasMaxLength(30);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.InterviewYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ShortListAppsId).HasColumnName("ShortListAppsID");

                entity.HasOne(d => d.ShortListApps)
                    .WithMany(p => p.Interview)
                    .HasForeignKey(d => d.ShortListAppsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Interview_ShortListedApplicatoin");
            });

            modelBuilder.Entity<InterviewBatch>(entity =>
            {
                entity.Property(e => e.InterviewBatchId).HasColumnName("InterviewBatchID");

                entity.Property(e => e.ApplicationSessionId).HasColumnName("ApplicationSessionID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.InterviewBatchNo).HasMaxLength(20);

                entity.Property(e => e.InterviewDate).HasColumnType("date");

                entity.Property(e => e.InterviewTime).HasColumnType("datetime");

                entity.Property(e => e.InterviewVenue).HasMaxLength(50);

                entity.Property(e => e.LoanAreaId).HasColumnName("LoanAreaID");

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PriorityAreaId).HasColumnName("PriorityAreaID");

                entity.Property(e => e.Smssend).HasColumnName("SMSSend");
            });

            modelBuilder.Entity<InterviewBatchDetails>(entity =>
            {
                entity.HasKey(e => e.InterviewBatchDetailId);

                entity.Property(e => e.InterviewBatchDetailId)
                    .HasColumnName("InterviewBatchDetailID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.Comments).HasMaxLength(150);

                entity.Property(e => e.InterviewBatchId).HasColumnName("InterviewBatchID");

                entity.Property(e => e.ShortListAppsId).HasColumnName("ShortListAppsID");

                entity.HasOne(d => d.InterviewBatchDetail)
                    .WithOne(p => p.InverseInterviewBatchDetail)
                    .HasForeignKey<InterviewBatchDetails>(d => d.InterviewBatchDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InterviewBatchDetails_InterviewBatchDetails1");

                entity.HasOne(d => d.InterviewBatch)
                    .WithMany(p => p.InterviewBatchDetails)
                    .HasForeignKey(d => d.InterviewBatchId)
                    .HasConstraintName("FK_InterviewBatchDetails_InterviewBatch");

                entity.HasOne(d => d.ShortListApps)
                    .WithMany(p => p.InterviewBatchDetails)
                    .HasForeignKey(d => d.ShortListAppsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InterviewBatchDetails_ShortListedApplication");
            });

            modelBuilder.Entity<Interviewer>(entity =>
            {
                entity.Property(e => e.InterviewerId).HasColumnName("InterviewerID");

                entity.Property(e => e.InterviewBatchId).HasColumnName("InterviewBatchID");

                entity.Property(e => e.InterviewerName).HasMaxLength(100);
            });

            modelBuilder.Entity<InterviewResponse>(entity =>
            {
                entity.Property(e => e.InterviewResponseId).HasColumnName("InterviewResponseID");

                entity.Property(e => e.InterviewId).HasColumnName("InterviewID");

                entity.Property(e => e.QuestionId).HasColumnName("QuestionID");

                entity.Property(e => e.QuestionResponse).HasMaxLength(200);

                entity.HasOne(d => d.Interview)
                    .WithMany(p => p.InterviewResponse)
                    .HasForeignKey(d => d.InterviewId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InterviewResponse_Interview");

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.InterviewResponse)
                    .HasForeignKey(d => d.QuestionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InterviewResponse_Question");
            });

            modelBuilder.Entity<InterviewResponseDetails>(entity =>
            {
                entity.HasKey(e => e.InterviewRespDetailsId);

                entity.Property(e => e.InterviewRespDetailsId).HasColumnName("InterviewRespDetailsID");

                entity.Property(e => e.InterviewResponseId).HasColumnName("InterviewResponseID");

                entity.Property(e => e.InterviewerId).HasColumnName("InterviewerID");

                entity.Property(e => e.QuestionId).HasColumnName("QuestionID");

                entity.Property(e => e.QuestionResponse)
                    .IsRequired()
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<Invoice>(entity =>
            {
                entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");

                entity.Property(e => e.Comments).HasMaxLength(150);

                entity.Property(e => e.InvoiceNumber).HasMaxLength(50);

                entity.Property(e => e.PaymentBatchId).HasColumnName("PaymentBatchID");
            });

            modelBuilder.Entity<InvoiceDetails>(entity =>
            {
                entity.HasKey(e => e.InvoiceDetailId);

                entity.Property(e => e.InvoiceDetailId).HasColumnName("InvoiceDetailID");

                entity.Property(e => e.AcademicYear).HasMaxLength(4);

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.ExpenseId).HasColumnName("ExpenseID");

                entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.StudyYear).HasMaxLength(10);

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.InvoiceDetails)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InvoiceDetails_Course");

                entity.HasOne(d => d.Expense)
                    .WithMany(p => p.InvoiceDetails)
                    .HasForeignKey(d => d.ExpenseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InvoiceDetails_ExpenseType");

                entity.HasOne(d => d.Invoice)
                    .WithMany(p => p.InvoiceDetails)
                    .HasForeignKey(d => d.InvoiceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InvoiceDetails_InvoiceRegister");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.InvoiceDetails)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InvoiceDetails_Student");
            });

            modelBuilder.Entity<InvoiceRegister>(entity =>
            {
                entity.HasKey(e => e.InvoiceId);

                entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.DeliveryNote).HasMaxLength(200);

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.InvoiceDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceNumber).HasMaxLength(20);

                entity.Property(e => e.InvoiceYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PurchaseNo).HasMaxLength(20);

                entity.HasOne(d => d.Institution)
                    .WithMany(p => p.InvoiceRegister)
                    .HasForeignKey(d => d.InstitutionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_InvoiceRegister_Institution");
            });

            modelBuilder.Entity<LaonCategory>(entity =>
            {
                entity.Property(e => e.LaonCategoryId).HasColumnName("LaonCategoryID");

                entity.Property(e => e.LoanCategoryName).HasMaxLength(50);
            });

            modelBuilder.Entity<LoanAccount>(entity =>
            {
                entity.HasKey(e => e.AccountId);

                entity.Property(e => e.AccountId).HasColumnName("AccountID");

                entity.Property(e => e.AccountCreationDate).HasColumnType("datetime");

                entity.Property(e => e.AccountName).HasMaxLength(50);

                entity.Property(e => e.AwardId).HasColumnName("AwardID");

                entity.Property(e => e.AwardListId).HasColumnName("AwardListID");

                entity.Property(e => e.BankAccountNo).HasMaxLength(20);

                entity.Property(e => e.BankAddress).HasMaxLength(70);

                entity.Property(e => e.BankId).HasColumnName("BankID");

                entity.Property(e => e.BranchCode).HasMaxLength(20);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CountryCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber).HasMaxLength(20);

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PayeeTypeId).HasColumnName("PayeeTypeID");

                entity.Property(e => e.RepaymentStartData).HasColumnType("datetime");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.SwiftCode).HasMaxLength(20);

                entity.HasOne(d => d.Bank)
                    .WithMany(p => p.LoanAccount)
                    .HasForeignKey(d => d.BankId)
                    .HasConstraintName("FK_LoanAccount_Bank");

                entity.HasOne(d => d.PayeeType)
                    .WithMany(p => p.LoanAccount)
                    .HasForeignKey(d => d.PayeeTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanAccount_PayeeTypeID");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.LoanAccount)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanAccount_Student");
            });

            modelBuilder.Entity<LoanApplication>(entity =>
            {
                entity.HasKey(e => e.ApplicationId);

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationDate).HasColumnType("datetime");

                entity.Property(e => e.ApplicationSessionId).HasColumnName("ApplicationSessionID");

                entity.Property(e => e.ApprovalDate).HasColumnType("datetime");

                entity.Property(e => e.ApprovedBy)
                    .HasColumnName("ApprovedBY")
                    .HasMaxLength(30);

                entity.Property(e => e.BatchId).HasColumnName("BatchID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ComputerNo).HasMaxLength(20);

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.EntryYear).HasMaxLength(4);

                entity.Property(e => e.ExitYear).HasMaxLength(4);

                entity.Property(e => e.FundingSourceId).HasColumnName("FundingSourceID");

                entity.Property(e => e.IndustryId).HasColumnName("IndustryID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.LoanCategoryId).HasColumnName("LoanCategoryID");

                entity.Property(e => e.LoanTypeId).HasColumnName("LoanTypeID");

                entity.Property(e => e.LoanYear)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.Notes).HasMaxLength(100);

                entity.Property(e => e.Ovcstatus).HasColumnName("OVCStatus");

                entity.Property(e => e.PriorityAreaId).HasColumnName("PriorityAreaID");

                entity.Property(e => e.ReferenceNumber).HasMaxLength(20);

                entity.Property(e => e.ReviewDate).HasColumnType("datetime");

                entity.Property(e => e.ReviewedBy).HasMaxLength(30);

                entity.Property(e => e.Scnumber)
                    .HasColumnName("SCNumber")
                    .HasMaxLength(20);

                entity.Property(e => e.Signature).HasMaxLength(213);

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.StudentNumber).HasMaxLength(20);

                entity.Property(e => e.StudentRegNo).HasMaxLength(18);

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.LoanApplication)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanApplication_Course");

                entity.HasOne(d => d.Industry)
                    .WithMany(p => p.LoanApplication)
                    .HasForeignKey(d => d.IndustryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanApplication_Industry");

                entity.HasOne(d => d.LoanYearNavigation)
                    .WithMany(p => p.LoanApplication)
                    .HasForeignKey(d => d.LoanYear)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanApplication_LoanYearSettings");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.LoanApplication)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanApplication_Student1");
            });

            modelBuilder.Entity<LoanType>(entity =>
            {
                entity.Property(e => e.LoanTypeId).HasColumnName("LoanTypeID");

                entity.Property(e => e.LoanTypeDescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LoanTypeAllocation>(entity =>
            {
                entity.Property(e => e.LoanTypeAllocationId).HasColumnName("LoanTypeAllocationID");

                entity.Property(e => e.BudgetAllocationId).HasColumnName("BudgetAllocationID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.LoanAreaId).HasColumnName("LoanAreaID");

                entity.Property(e => e.LoanCategoryId).HasColumnName("LoanCategoryID");

                entity.Property(e => e.LoanTypeId).HasColumnName("LoanTypeID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.HasOne(d => d.BudgetAllocation)
                    .WithMany(p => p.LoanTypeAllocation)
                    .HasForeignKey(d => d.BudgetAllocationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanTypeAllocation_BudgetAllocation");

                entity.HasOne(d => d.LoanType)
                    .WithMany(p => p.LoanTypeAllocation)
                    .HasForeignKey(d => d.LoanTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanTypeAllocation_LoanType");
            });

            modelBuilder.Entity<LoanYearSettings>(entity =>
            {
                entity.HasKey(e => e.LoanYear);

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.ApplicationEndDate).HasColumnType("datetime");

                entity.Property(e => e.ApplicationStartDate).HasColumnType("datetime");

                entity.Property(e => e.ApprovalDate).HasColumnType("datetime");

                entity.Property(e => e.ApprovedBy)
                    .HasColumnName("ApprovedBY")
                    .HasMaxLength(30);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.LoanTypeId).HasColumnName("LoanTypeID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ReviewDate).HasColumnType("datetime");

                entity.Property(e => e.ReviewedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<LoginInfo>(entity =>
            {
                entity.HasKey(e => e.SessionId);

                entity.Property(e => e.SessionId).HasColumnName("SessionID");

                entity.Property(e => e.HostName).HasMaxLength(50);

                entity.Property(e => e.InterfaceDescription).HasMaxLength(50);

                entity.Property(e => e.InterfaceName).HasMaxLength(50);

                entity.Property(e => e.Ipaddress)
                    .HasColumnName("IPAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.LoginDateTime).HasColumnType("datetime");

                entity.Property(e => e.LogoutDate).HasColumnType("datetime");

                entity.Property(e => e.Macaddress)
                    .HasColumnName("MACAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.Protocol).HasMaxLength(50);

                entity.Property(e => e.PublicIp)
                    .HasColumnName("PublicIP")
                    .HasMaxLength(50);

                entity.Property(e => e.SessionKey).HasMaxLength(300);

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<LogMain>(entity =>
            {
                entity.HasKey(e => e.LogId);

                entity.Property(e => e.LogId).HasColumnName("LogID");

                entity.Property(e => e.ActionId).HasColumnName("ActionID");

                entity.Property(e => e.CalledFunction).HasMaxLength(70);

                entity.Property(e => e.ComputerName).HasMaxLength(50);

                entity.Property(e => e.ComputerNo).HasMaxLength(30);

                entity.Property(e => e.Form)
                    .HasColumnName("form")
                    .HasMaxLength(70);

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.Ipaddress)
                    .HasColumnName("IPAddress")
                    .HasMaxLength(30);

                entity.Property(e => e.LoanNumber).HasMaxLength(20);

                entity.Property(e => e.LogTime).HasColumnType("datetime");

                entity.Property(e => e.LogTypeId).HasColumnName("LogTypeID");

                entity.Property(e => e.LoginInfoId).HasColumnName("LoginInfoID");

                entity.Property(e => e.ModuleId).HasColumnName("ModuleID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(30);

                entity.Property(e => e.UserRight).HasMaxLength(50);

                entity.HasOne(d => d.Action)
                    .WithMany(p => p.LogMain)
                    .HasForeignKey(d => d.ActionId)
                    .HasConstraintName("FK_LogMain_Action");

                entity.HasOne(d => d.LogType)
                    .WithMany(p => p.LogMain)
                    .HasForeignKey(d => d.LogTypeId)
                    .HasConstraintName("FK_LogMain_LogType");

                entity.HasOne(d => d.Module)
                    .WithMany(p => p.LogMain)
                    .HasForeignKey(d => d.ModuleId)
                    .HasConstraintName("FK_LogMain_Module");
            });

            modelBuilder.Entity<LogType>(entity =>
            {
                entity.Property(e => e.LogTypeId)
                    .HasColumnName("LogTypeID")
                    .ValueGeneratedNever();

                entity.Property(e => e.LogTypeName).HasMaxLength(50);
            });

            modelBuilder.Entity<Message>(entity =>
            {
                entity.Property(e => e.MessageId).HasColumnName("MessageID");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.ExpireDate).HasColumnType("datetime");

                entity.Property(e => e.Header).HasMaxLength(70);

                entity.Property(e => e.Message1)
                    .HasColumnName("Message")
                    .HasMaxLength(550);

                entity.Property(e => e.ReferanceId).HasColumnName("ReferanceID");

                entity.Property(e => e.RegistryBy).HasMaxLength(30);

                entity.Property(e => e.RegistryDate).HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<MessageDetail>(entity =>
            {
                entity.Property(e => e.MessageDetailId).HasColumnName("MessageDetailID");

                entity.Property(e => e.MessageId).HasColumnName("MessageID");

                entity.Property(e => e.Recipient).HasMaxLength(50);
            });

            modelBuilder.Entity<Ministry>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.Property(e => e.Code)
                    .HasMaxLength(2)
                    .ValueGeneratedNever();

                entity.Property(e => e.Name).HasMaxLength(150);
            });

            modelBuilder.Entity<Module>(entity =>
            {
                entity.Property(e => e.ModuleId).HasColumnName("ModuleID");

                entity.Property(e => e.Description).HasMaxLength(100);

                entity.Property(e => e.ModuleName).HasMaxLength(50);
            });

            modelBuilder.Entity<Nationality>(entity =>
            {
                entity.Property(e => e.NationalityId)
                    .HasColumnName("NationalityID")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.NationalityName).HasMaxLength(50);
            });

            modelBuilder.Entity<News>(entity =>
            {
                entity.Property(e => e.NewsId).HasColumnName("NewsID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.NewsDetails).HasMaxLength(1000);

                entity.Property(e => e.NewsTitle).HasMaxLength(200);

                entity.Property(e => e.PublishDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<OngoingBudget>(entity =>
            {
                entity.HasKey(e => e.LoanYear);

                entity.Property(e => e.LoanYear)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();
            });

            modelBuilder.Entity<Parents>(entity =>
            {
                entity.HasKey(e => e.ParentId);

                entity.Property(e => e.ParentId).HasColumnName("ParentID");

                entity.Property(e => e.CellPhoneNo).HasMaxLength(20);

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.Employer).HasMaxLength(70);

                entity.Property(e => e.EmploymentStatusId).HasColumnName("EmploymentStatusID");

                entity.Property(e => e.HighestEducation).HasMaxLength(50);

                entity.Property(e => e.Name).HasMaxLength(70);

                entity.Property(e => e.OthersRegionName).HasMaxLength(50);

                entity.Property(e => e.ParentTypeId).HasColumnName("ParentTypeID");

                entity.Property(e => e.Pin)
                    .HasColumnName("PIN")
                    .HasMaxLength(13);

                entity.Property(e => e.PlaceOfBirth).HasMaxLength(70);

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.Surname).HasMaxLength(70);

                entity.Property(e => e.Telephone).HasMaxLength(20);

                entity.HasOne(d => d.EmploymentStatus)
                    .WithMany(p => p.Parents)
                    .HasForeignKey(d => d.EmploymentStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Parents_EmploymentStatus");

                entity.HasOne(d => d.ParentType)
                    .WithMany(p => p.Parents)
                    .HasForeignKey(d => d.ParentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Parents_ParentType");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.Parents)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Parents_Student");
            });

            modelBuilder.Entity<ParentStatus>(entity =>
            {
                entity.Property(e => e.ParentStatusId)
                    .HasColumnName("ParentStatusID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Description).HasMaxLength(50);
            });

            modelBuilder.Entity<ParentType>(entity =>
            {
                entity.Property(e => e.ParentTypeId).HasColumnName("ParentTypeID");

                entity.Property(e => e.ParentTypeName).HasMaxLength(50);
            });

            modelBuilder.Entity<PayeeType>(entity =>
            {
                entity.Property(e => e.PayeeTypeId).HasColumnName("PayeeTypeID");

                entity.Property(e => e.Description).HasMaxLength(50);
            });

            modelBuilder.Entity<PaymentBatch>(entity =>
            {
                entity.Property(e => e.PaymentBatchId).HasColumnName("PaymentBatchID");

                entity.Property(e => e.BatchCode).HasMaxLength(12);

                entity.Property(e => e.BatchName).HasMaxLength(50);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ChequeNo).HasMaxLength(50);

                entity.Property(e => e.Description).HasMaxLength(150);

                entity.Property(e => e.FileReferenceNo).HasMaxLength(50);

                entity.Property(e => e.FolderId).HasColumnName("FolderID");

                entity.Property(e => e.InstitutionId).HasColumnName("InstitutionID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PaymentDate).HasColumnType("date");

                entity.Property(e => e.SupplierId).HasColumnName("SupplierID");

                entity.Property(e => e.VoucherNo).HasMaxLength(50);

                entity.Property(e => e.Year)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.HasOne(d => d.Folder)
                    .WithMany(p => p.PaymentBatch)
                    .HasForeignKey(d => d.FolderId)
                    .HasConstraintName("FK_PaymentBatch_Folder");
            });

            modelBuilder.Entity<PaymentBatchDetail>(entity =>
            {
                entity.Property(e => e.PaymentBatchDetailId).HasColumnName("PaymentBatchDetailID");

                entity.Property(e => e.AcademicYear).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.AccountId).HasColumnName("AccountID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.BatchStatus).HasMaxLength(30);

                entity.Property(e => e.CaptureBy).HasMaxLength(30);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.ComputerNo).HasMaxLength(20);

                entity.Property(e => e.Course).HasMaxLength(200);

                entity.Property(e => e.Institution).HasMaxLength(200);

                entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");

                entity.Property(e => e.MessageText).HasMaxLength(300);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.Name).HasMaxLength(200);

                entity.Property(e => e.PaymentBatchId).HasColumnName("PaymentBatchID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.StudyYear).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.UploadMessage).HasMaxLength(200);
            });

            modelBuilder.Entity<PaymentBatchDetailHeads>(entity =>
            {
                entity.Property(e => e.PaymentBatchDetailHeadsId).HasColumnName("PaymentBatchDetailHeadsID");

                entity.Property(e => e.FinanceRequestTypeId).HasColumnName("FinanceRequestTypeID");

                entity.Property(e => e.PaymentBatchDetailId).HasColumnName("PaymentBatchDetailID");

                entity.HasOne(d => d.PaymentBatchDetail)
                    .WithMany(p => p.PaymentBatchDetailHeads)
                    .HasForeignKey(d => d.PaymentBatchDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PaymentBatchDetailHeads_PaymentBatchDetail");
            });

            modelBuilder.Entity<PaymentBatchSummary>(entity =>
            {
                entity.Property(e => e.AccountHead).HasMaxLength(50);

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.InvoiceNo).HasMaxLength(30);
            });

            modelBuilder.Entity<PaymentDetails>(entity =>
            {
                entity.HasKey(e => e.PaymentDetailId);

                entity.Property(e => e.PaymentDetailId).HasColumnName("PaymentDetailID");

                entity.Property(e => e.AccountId).HasColumnName("AccountID");

                entity.Property(e => e.ExpenceTypeId).HasColumnName("ExpenceTypeID");

                entity.Property(e => e.PaymentCheque).HasMaxLength(20);

                entity.Property(e => e.PaymentDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentInfoId).HasColumnName("PaymentInfoID");

                entity.HasOne(d => d.PaymentInfo)
                    .WithMany(p => p.PaymentDetails)
                    .HasForeignKey(d => d.PaymentInfoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PaymentDetails_PaymentInfo");
            });

            modelBuilder.Entity<PaymentFile>(entity =>
            {
                entity.HasKey(e => e.FileId);

                entity.Property(e => e.FileId).HasColumnName("FileID");

                entity.Property(e => e.DateOfCreation).HasColumnType("datetime");

                entity.Property(e => e.FileContent).HasColumnType("image");

                entity.Property(e => e.FileName).HasMaxLength(500);
            });

            modelBuilder.Entity<PaymentInfo>(entity =>
            {
                entity.Property(e => e.PaymentInfoId).HasColumnName("PaymentInfoID");

                entity.Property(e => e.ApprovedBy).HasMaxLength(30);

                entity.Property(e => e.BankAccountNo).HasMaxLength(20);

                entity.Property(e => e.BankId).HasColumnName("BankID");

                entity.Property(e => e.BatchNo).HasMaxLength(50);

                entity.Property(e => e.BranchCode).HasMaxLength(50);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ChequeNo).HasMaxLength(50);

                entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PayeeName).HasMaxLength(50);

                entity.Property(e => e.PaymentDate).HasColumnType("datetime");

                entity.Property(e => e.ReviewedBy).HasMaxLength(30);
            });

            modelBuilder.Entity<PaymentMode>(entity =>
            {
                entity.Property(e => e.PaymentModeId).HasColumnName("PaymentModeID");

                entity.Property(e => e.PaymentModeName).HasMaxLength(50);
            });

            modelBuilder.Entity<PaymentTerm>(entity =>
            {
                entity.HasKey(e => e.PaymentTermsId);

                entity.Property(e => e.PaymentTermsId).HasColumnName("PaymentTermsID");

                entity.Property(e => e.PaymentTerms).HasMaxLength(50);
            });

            modelBuilder.Entity<PaymentType>(entity =>
            {
                entity.Property(e => e.PaymentTypeId).HasColumnName("PaymentTypeID");

                entity.Property(e => e.Description).HasMaxLength(50);
            });

            modelBuilder.Entity<PointOfPay>(entity =>
            {
                entity.Property(e => e.PointOfPayId).HasColumnName("PointOfPayID");

                entity.Property(e => e.Description).HasMaxLength(50);
            });

            modelBuilder.Entity<Policy>(entity =>
            {
                entity.Property(e => e.PolicyId).HasColumnName("PolicyID");

                entity.Property(e => e.Appovedby)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.ApprovedDate).HasColumnType("datetime");

                entity.Property(e => e.BankAccno)
                    .HasColumnName("BankACCNo")
                    .HasMaxLength(30);

                entity.Property(e => e.BankCode).HasMaxLength(10);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.Capturedby)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.Comments).HasMaxLength(50);

                entity.Property(e => e.EffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.EmpSourceId).HasColumnName("EmpSourceID");

                entity.Property(e => e.EmployeeId).HasColumnName("EmployeeID");

                entity.Property(e => e.EmployeeNo).HasMaxLength(30);

                entity.Property(e => e.PolicyNumber).HasMaxLength(150);

                entity.Property(e => e.PolicyReferenceNo).HasMaxLength(50);

                entity.Property(e => e.ReEndDate).HasColumnType("datetime");

                entity.Property(e => e.ReStartDate).HasColumnType("datetime");

                entity.Property(e => e.RejectDate).HasColumnType("datetime");

                entity.Property(e => e.RejectReason).HasMaxLength(50);

                entity.Property(e => e.Rejectby).HasMaxLength(30);

                entity.Property(e => e.ReviewDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Reviewedby).HasMaxLength(30);

                entity.Property(e => e.SattelmentBy).HasMaxLength(30);

                entity.Property(e => e.SattelmentDate).HasColumnType("datetime");

                entity.Property(e => e.StattelmentReasonId).HasColumnName("StattelmentReasonID");

                entity.Property(e => e.SuspensionDate).HasColumnType("datetime");

                entity.Property(e => e.UniqueNo).HasMaxLength(150);
            });

            modelBuilder.Entity<PriorityArea>(entity =>
            {
                entity.Property(e => e.PriorityAreaId).HasColumnName("PriorityAreaID");

                entity.Property(e => e.PriorityAreaDescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PriorityAreaAllocation>(entity =>
            {
                entity.Property(e => e.PriorityAreaAllocationId).HasColumnName("PriorityAreaAllocationID");

                entity.Property(e => e.LoanTypeAllocationId).HasColumnName("LoanTypeAllocationID");

                entity.Property(e => e.PriorityAreaId).HasColumnName("PriorityAreaID");

                entity.HasOne(d => d.LoanTypeAllocation)
                    .WithMany(p => p.PriorityAreaAllocation)
                    .HasForeignKey(d => d.LoanTypeAllocationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PriorityAreaAllocation_LoanTypeAllocation");

                entity.HasOne(d => d.PriorityArea)
                    .WithMany(p => p.PriorityAreaAllocation)
                    .HasForeignKey(d => d.PriorityAreaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PriorityAreaAllocation_PriorityArea");
            });

            modelBuilder.Entity<PurchaseOrder>(entity =>
            {
                entity.Property(e => e.PurchaseOrderId).HasColumnName("PurchaseOrderID");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CapturedDate).HasColumnType("datetime");

                entity.Property(e => e.IssedBy).HasMaxLength(30);

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.OrderDate).HasColumnType("datetime");

                entity.Property(e => e.OrderNumber).HasMaxLength(30);

                entity.Property(e => e.ProjectCode).HasMaxLength(20);

                entity.Property(e => e.ReportingCode).HasMaxLength(20);

                entity.Property(e => e.RespCode).HasMaxLength(20);

                entity.Property(e => e.SupplierCode).HasMaxLength(20);
            });

            modelBuilder.Entity<PurchaseOrderDetail>(entity =>
            {
                entity.Property(e => e.PurchaseOrderDetailId).HasColumnName("PurchaseOrderDetailID");

                entity.Property(e => e.AcademicYear).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CapturedDate).HasColumnType("datetime");

                entity.Property(e => e.ComputerNo).HasMaxLength(20);

                entity.Property(e => e.DetailItem).HasMaxLength(20);

                entity.Property(e => e.DetailItemId).HasColumnName("DetailItemID");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.PurchasOrderId).HasColumnName("PurchasOrderID");

                entity.Property(e => e.StudentName).HasMaxLength(200);

                entity.Property(e => e.SupplierType).HasMaxLength(50);

                entity.Property(e => e.UploadMessage).HasMaxLength(200);
            });

            modelBuilder.Entity<Question>(entity =>
            {
                entity.Property(e => e.QuestionId).HasColumnName("QuestionID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.MaxScore).HasColumnType("decimal(8, 2)");

                entity.Property(e => e.MinScore).HasColumnType("decimal(8, 2)");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.QuestionCategoryId).HasColumnName("QuestionCategoryID");

                entity.Property(e => e.QuestionDescription).HasMaxLength(200);

                entity.Property(e => e.QuestionTypeId).HasColumnName("QuestionTypeID");

                entity.HasOne(d => d.QuestionCategory)
                    .WithMany(p => p.Question)
                    .HasForeignKey(d => d.QuestionCategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Question_QuestionCategory");

                entity.HasOne(d => d.QuestionType)
                    .WithMany(p => p.Question)
                    .HasForeignKey(d => d.QuestionTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Question_QuestionType");
            });

            modelBuilder.Entity<QuestionCategory>(entity =>
            {
                entity.Property(e => e.QuestionCategoryId).HasColumnName("QuestionCategoryID");

                entity.Property(e => e.QuestionCategoryName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<QuestionManager>(entity =>
            {
                entity.HasKey(e => e.Qmid);

                entity.Property(e => e.Qmid).HasColumnName("QMID");

                entity.Property(e => e.ApprovedBy)
                    .HasColumnName("ApprovedBY")
                    .HasMaxLength(30);

                entity.Property(e => e.ApprovedDate).HasColumnType("datetime");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.QuestionId).HasColumnName("QuestionID");

                entity.Property(e => e.QuestionYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.QuestionManager)
                    .HasForeignKey(d => d.QuestionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_QuestionManager_Question");
            });

            modelBuilder.Entity<QuestionOption>(entity =>
            {
                entity.Property(e => e.QuestionOptionId).HasColumnName("QuestionOptionID");

                entity.Property(e => e.ApprovedBy).HasMaxLength(30);

                entity.Property(e => e.ApprovedDate).HasColumnType("datetime");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.OptionCode)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.OptionDescription).HasMaxLength(50);

                entity.Property(e => e.QuestionId).HasColumnName("QuestionID");

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.QuestionOption)
                    .HasForeignKey(d => d.QuestionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_QuestionOption_Question");
            });

            modelBuilder.Entity<QuestionType>(entity =>
            {
                entity.Property(e => e.QuestionTypeId).HasColumnName("QuestionTypeID");

                entity.Property(e => e.QuestonTypeDescription)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<References>(entity =>
            {
                entity.HasKey(e => e.ReferencId);

                entity.Property(e => e.ReferencId).HasColumnName("ReferencID");

                entity.Property(e => e.CellPhone).HasMaxLength(20);

                entity.Property(e => e.Name).HasMaxLength(70);

                entity.Property(e => e.OthersRegionName).HasMaxLength(50);

                entity.Property(e => e.Pin)
                    .HasColumnName("PIN")
                    .HasMaxLength(13);

                entity.Property(e => e.Relationship).HasMaxLength(40);

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.Surname).HasMaxLength(70);

                entity.Property(e => e.TelephoneNo).HasMaxLength(20);

                entity.HasOne(d => d.RegionCodeNavigation)
                    .WithMany(p => p.References)
                    .HasForeignKey(d => d.RegionCode)
                    .HasConstraintName("FK_References_Region");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.References)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_References_Student");
            });

            modelBuilder.Entity<Region>(entity =>
            {
                entity.HasKey(e => e.RegionCode);

                entity.Property(e => e.RegionCode).ValueGeneratedNever();

                entity.Property(e => e.RegionName).HasMaxLength(50);
            });

            modelBuilder.Entity<RepaymentDetail>(entity =>
            {
                entity.Property(e => e.RepaymentDetailId).HasColumnName("RepaymentDetailID");

                entity.Property(e => e.AccountId).HasColumnName("AccountID");

                entity.Property(e => e.RepaymentCheque).HasMaxLength(20);

                entity.Property(e => e.RepaymentId).HasColumnName("RepaymentID");

                entity.HasOne(d => d.Repayment)
                    .WithMany(p => p.RepaymentDetail)
                    .HasForeignKey(d => d.RepaymentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RepaymentDetail_RepaymentRegister");
            });

            modelBuilder.Entity<RepaymentRegister>(entity =>
            {
                entity.HasKey(e => e.RepaymentId);

                entity.Property(e => e.RepaymentId).HasColumnName("RepaymentID");

                entity.Property(e => e.BankId).HasColumnName("BankID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.EmployerId).HasColumnName("EmployerID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PointOfPayId).HasColumnName("PointOfPayID");

                entity.Property(e => e.RepaymentDate).HasColumnType("datetime");

                entity.Property(e => e.SourceTypeId).HasColumnName("SourceTypeID");

                entity.HasOne(d => d.SourceType)
                    .WithMany(p => p.RepaymentRegister)
                    .HasForeignKey(d => d.SourceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RepaymentRegister_RepaymentSource");
            });

            modelBuilder.Entity<RepaymentSource>(entity =>
            {
                entity.HasKey(e => e.SourceTypeId);

                entity.Property(e => e.SourceTypeId).HasColumnName("SourceTypeID");

                entity.Property(e => e.Description).HasMaxLength(50);
            });

            modelBuilder.Entity<ReportingStatus>(entity =>
            {
                entity.Property(e => e.ReportingStatusId).HasColumnName("ReportingStatusID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.Notes).HasMaxLength(250);

                entity.Property(e => e.ReportingDate).HasColumnType("date");

                entity.Property(e => e.ReportingTypeId).HasColumnName("ReportingTypeID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.HasOne(d => d.ReportingType)
                    .WithMany(p => p.ReportingStatus)
                    .HasForeignKey(d => d.ReportingTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ReportingStatus_ReportingType");
            });

            modelBuilder.Entity<ReportingType>(entity =>
            {
                entity.Property(e => e.ReportingTypeId).HasColumnName("ReportingTypeID");

                entity.Property(e => e.Description).HasMaxLength(50);
            });

            modelBuilder.Entity<ReportingTypeValues>(entity =>
            {
                entity.HasKey(e => e.ReportingTypeValueId);

                entity.Property(e => e.ReportingTypeValueId).HasColumnName("ReportingTypeValueID");

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.ReportingTypeId).HasColumnName("ReportingTypeID");

                entity.HasOne(d => d.ReportingType)
                    .WithMany(p => p.ReportingTypeValues)
                    .HasForeignKey(d => d.ReportingTypeId)
                    .HasConstraintName("FK_ReportingTypeValues_ReportingType");
            });

            modelBuilder.Entity<ResourceFile>(entity =>
            {
                entity.HasKey(e => e.ResourceId);

                entity.Property(e => e.ResourceId).HasColumnName("ResourceID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.ResourceDescription).HasMaxLength(300);

                entity.Property(e => e.ResourceFile1)
                    .HasColumnName("ResourceFile")
                    .HasColumnType("image");

                entity.Property(e => e.ResourceFileName).HasMaxLength(200);

                entity.Property(e => e.ResourceFileTitle).HasMaxLength(150);

                entity.Property(e => e.ResourceFileType).HasMaxLength(10);
            });

            modelBuilder.Entity<Selection>(entity =>
            {
                entity.Property(e => e.SelectionId).HasColumnName("SelectionID");

                entity.Property(e => e.ApplicationSessionId).HasColumnName("ApplicationSessionID");

                entity.Property(e => e.ApprovedBy).HasMaxLength(30);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CourseId).HasColumnName("CourseID");

                entity.Property(e => e.LoanAreaId).HasColumnName("LoanAreaID");

                entity.Property(e => e.LoanCategoryId).HasColumnName("LoanCategoryID");

                entity.Property(e => e.LoanTypeId).HasColumnName("LoanTypeID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PriorityAreaAllocationId).HasColumnName("PriorityAreaAllocationID");

                entity.Property(e => e.SelectedBy).HasMaxLength(30);

                entity.Property(e => e.SelectionDate).HasColumnType("datetime");

                entity.Property(e => e.SelectionTitle).HasMaxLength(50);

                entity.Property(e => e.SelectionYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ShortListedApplication>(entity =>
            {
                entity.HasKey(e => e.ShortListAppsId);

                entity.Property(e => e.ShortListAppsId).HasColumnName("ShortListAppsID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.IsSaf).HasColumnName("IsSAF");

                entity.Property(e => e.IsSsl).HasColumnName("IsSSL");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.SafselectionType)
                    .HasColumnName("SAFSelectionType")
                    .HasMaxLength(10);

                entity.Property(e => e.SelectionId).HasColumnName("SelectionID");

                entity.Property(e => e.ShortListedYear)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.SslselectionType)
                    .HasColumnName("SSLSelectionType")
                    .HasMaxLength(10);

                entity.HasOne(d => d.Selection)
                    .WithMany(p => p.ShortListedApplication)
                    .HasForeignKey(d => d.SelectionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ShortListedApplicatoin_Selection");
            });

            modelBuilder.Entity<Slafaccount>(entity =>
            {
                entity.ToTable("SLAFAccount");

                entity.Property(e => e.SlafaccountId).HasColumnName("SLAFAccountID");

                entity.Property(e => e.AccountMasterCode).HasMaxLength(12);

                entity.Property(e => e.AccountTypeId).HasColumnName("AccountTypeID");

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.ApproveDate).HasColumnType("datetime");

                entity.Property(e => e.ApprovedBy).HasMaxLength(30);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.SlafaccountStatus).HasColumnName("SLAFAccountStatus");
            });

            modelBuilder.Entity<SocioEconomic>(entity =>
            {
                entity.HasKey(e => e.SocioId);

                entity.Property(e => e.SocioId).HasColumnName("SocioID");

                entity.Property(e => e.Answer).HasMaxLength(50);

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.HighestScore).HasColumnType("decimal(8, 2)");

                entity.Property(e => e.QuestionId).HasColumnName("QuestionID");

                entity.Property(e => e.QuestionOptionId).HasColumnName("QuestionOptionID");

                entity.Property(e => e.ScoreObtained).HasColumnType("decimal(8, 2)");
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.BirthPlace).HasMaxLength(70);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CellPhone).HasMaxLength(20);

                entity.Property(e => e.Checksum).HasMaxLength(100);

                entity.Property(e => e.ComputerNo).HasMaxLength(50);

                entity.Property(e => e.CountryCode).HasMaxLength(3);

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.EmailAddress).HasMaxLength(70);

                entity.Property(e => e.Gender)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeAddress).HasMaxLength(200);

                entity.Property(e => e.MaritalStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MiddleName).HasMaxLength(70);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.Mountain).HasMaxLength(120);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.NationalityId)
                    .HasColumnName("NationalityID")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Nop)
                    .HasColumnName("NOP")
                    .HasMaxLength(50);

                entity.Property(e => e.Pin)
                    .IsRequired()
                    .HasColumnName("PIN")
                    .HasMaxLength(50);

                entity.Property(e => e.PostCode).HasMaxLength(10);

                entity.Property(e => e.PostalAddress).HasMaxLength(200);

                entity.Property(e => e.River).HasMaxLength(120);

                entity.Property(e => e.SecretCode).HasMaxLength(50);

                entity.Property(e => e.Surname)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.TaxNumber).HasMaxLength(50);

                entity.Property(e => e.Telephone).HasMaxLength(20);

                entity.Property(e => e.UploadMessage).HasMaxLength(200);

                entity.Property(e => e.VarificationCode).HasMaxLength(50);

                entity.HasOne(d => d.ChiefCodeNavigation)
                    .WithMany(p => p.Student)
                    .HasForeignKey(d => d.ChiefCode)
                    .HasConstraintName("FK_Student_Chief");

                entity.HasOne(d => d.CountryCodeNavigation)
                    .WithMany(p => p.Student)
                    .HasForeignKey(d => d.CountryCode)
                    .HasConstraintName("FK_Student_Country");

                entity.HasOne(d => d.Nationality)
                    .WithMany(p => p.Student)
                    .HasForeignKey(d => d.NationalityId)
                    .HasConstraintName("FK_Student_Nationality");

                entity.HasOne(d => d.RegionCodeNavigation)
                    .WithMany(p => p.Student)
                    .HasForeignKey(d => d.RegionCode)
                    .HasConstraintName("FK_Student_Region");
            });

            modelBuilder.Entity<StudentAttachmentRelation>(entity =>
            {
                entity.Property(e => e.StudentAttachmentRelationId).HasColumnName("StudentAttachmentRelationID");

                entity.Property(e => e.AttachmentId).HasColumnName("AttachmentID");

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.Year)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StudentEntry>(entity =>
            {
                entity.Property(e => e.StudentEntryId).HasColumnName("StudentEntryID");

                entity.Property(e => e.BirthPlace).HasMaxLength(70);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CellPhone).HasMaxLength(20);

                entity.Property(e => e.Checksum).HasMaxLength(100);

                entity.Property(e => e.ComputerNo).HasMaxLength(50);

                entity.Property(e => e.CountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.EmailAddress).HasMaxLength(70);

                entity.Property(e => e.Gender)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeAddress).HasMaxLength(200);

                entity.Property(e => e.MaritalStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MiddleName).HasMaxLength(70);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.NationalityId)
                    .HasColumnName("NationalityID")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Notes).HasMaxLength(200);

                entity.Property(e => e.Pin)
                    .IsRequired()
                    .HasColumnName("PIN")
                    .HasMaxLength(50);

                entity.Property(e => e.PostCode).HasMaxLength(10);

                entity.Property(e => e.PostalAddress).HasMaxLength(200);

                entity.Property(e => e.SecretCode).HasMaxLength(50);

                entity.Property(e => e.StudentId).HasColumnName("StudentID");

                entity.Property(e => e.Surname)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.TaxNumber).HasMaxLength(50);

                entity.Property(e => e.Telephone).HasMaxLength(20);

                entity.Property(e => e.VarificationCode).HasMaxLength(50);
            });

            modelBuilder.Entity<Subject>(entity =>
            {
                entity.Property(e => e.SubjectId).HasColumnName("SubjectID");

                entity.Property(e => e.SubjectCode).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.SubjectName).HasMaxLength(50);
            });

            modelBuilder.Entity<Supplier>(entity =>
            {
                entity.Property(e => e.SupplierId).HasColumnName("SupplierID");

                entity.Property(e => e.BusinessAddress).HasMaxLength(200);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CellPhone).HasMaxLength(20);

                entity.Property(e => e.EmailAddress).HasMaxLength(70);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PostCode).HasMaxLength(10);

                entity.Property(e => e.PostalAddress).HasMaxLength(200);

                entity.Property(e => e.SupplierCode).HasMaxLength(20);

                entity.Property(e => e.SupplierName).HasMaxLength(70);

                entity.Property(e => e.Telephone).HasMaxLength(20);
            });

            modelBuilder.Entity<SupplierAccount>(entity =>
            {
                entity.Property(e => e.SupplierAccountId).HasColumnName("SupplierAccountID");

                entity.Property(e => e.AccountName).HasMaxLength(50);

                entity.Property(e => e.AccountNo).HasMaxLength(20);

                entity.Property(e => e.BankAccountNo).HasMaxLength(50);

                entity.Property(e => e.BankAddress).HasMaxLength(150);

                entity.Property(e => e.BankId)
                    .HasColumnName("BankID")
                    .HasMaxLength(50);

                entity.Property(e => e.BankName).HasMaxLength(150);

                entity.Property(e => e.BranchCode).HasMaxLength(50);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.ContactPersonId).HasColumnName("ContactPersonID");

                entity.Property(e => e.Country)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber).HasMaxLength(15);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.PayeeTypeId).HasColumnName("PayeeTypeID");

                entity.Property(e => e.SupplierId).HasColumnName("SupplierID");

                entity.Property(e => e.SwiftCode).HasMaxLength(20);

                entity.HasOne(d => d.ContactPerson)
                    .WithMany(p => p.SupplierAccount)
                    .HasForeignKey(d => d.ContactPersonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SupplierAccount_ContactPerson");

                entity.HasOne(d => d.Supplier)
                    .WithMany(p => p.SupplierAccount)
                    .HasForeignKey(d => d.SupplierId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SupplierAccount_Supplier1");
            });

            modelBuilder.Entity<TempNationalId>(entity =>
            {
                entity.HasKey(e => e.TempNationalIds);

                entity.ToTable("TempNationalID");

                entity.Property(e => e.TempNationalIds).HasColumnName("TempNationalIDS");

                entity.Property(e => e.NationalId)
                    .HasColumnName("NationalID")
                    .HasMaxLength(13);
            });

            modelBuilder.Entity<TermCondition>(entity =>
            {
                entity.Property(e => e.TermConditionId).HasColumnName("TermConditionID");

                entity.Property(e => e.AccountCreationDate).HasColumnType("datetime");

                entity.Property(e => e.AccountId).HasColumnName("AccountID");

                entity.Property(e => e.AccountName).HasMaxLength(50);

                entity.Property(e => e.BankAddress).HasMaxLength(70);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CountryCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InstitutionAccountId).HasColumnName("InstitutionAccountID");

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.SupplierAccountId).HasColumnName("SupplierAccountID");

                entity.Property(e => e.SwiftCode).HasMaxLength(20);
            });

            modelBuilder.Entity<Transaction>(entity =>
            {
                entity.Property(e => e.TransactionId).HasColumnName("TransactionID");

                entity.Property(e => e.AccountId).HasColumnName("AccountID");

                entity.Property(e => e.AccountMasterCode).HasMaxLength(12);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.EmployerId).HasColumnName("EmployerID");

                entity.Property(e => e.InstitutionAccountId).HasColumnName("InstitutionAccountID");

                entity.Property(e => e.PaymentBatchId).HasColumnName("PaymentBatchID");

                entity.Property(e => e.SupplierAccountId).HasColumnName("SupplierAccountID");
            });

            modelBuilder.Entity<TransferType>(entity =>
            {
                entity.Property(e => e.TransferTypeId).HasColumnName("TransferTypeID");

                entity.Property(e => e.TransferTypeName).HasMaxLength(50);
            });

            modelBuilder.Entity<UserRight>(entity =>
            {
                entity.HasKey(e => e.AccessRight);

                entity.Property(e => e.RightDescription).HasMaxLength(50);

                entity.Property(e => e.RightName).HasMaxLength(50);
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(30)
                    .ValueGeneratedNever();

                entity.Property(e => e.CellPhone).HasMaxLength(20);

                entity.Property(e => e.Email).HasMaxLength(70);

                entity.Property(e => e.Macaddress)
                    .HasColumnName("MACAddress")
                    .HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Network).HasMaxLength(50);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.RegistryDate).HasColumnType("datetime");

                entity.Property(e => e.Surname).HasMaxLength(50);

                entity.Property(e => e.Telehphone).HasMaxLength(20);

                entity.Property(e => e.UserTypeId).HasColumnName("UserTypeID");

                entity.HasOne(d => d.AccessRightNavigation)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.AccessRight)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Users_userright");

                entity.HasOne(d => d.UserType)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.UserTypeId)
                    .HasConstraintName("FK_Users_UserTypes");
            });

            modelBuilder.Entity<UserTypes>(entity =>
            {
                entity.HasKey(e => e.UserTypeId);

                entity.Property(e => e.UserTypeId).HasColumnName("UserTypeID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Voucher>(entity =>
            {
                entity.Property(e => e.VoucherId).HasColumnName("VoucherID");

                entity.Property(e => e.BatchNumber).HasMaxLength(50);

                entity.Property(e => e.CaptureDate).HasColumnType("datetime");

                entity.Property(e => e.CapturedBy).HasMaxLength(30);

                entity.Property(e => e.CreditorDateSigned).HasColumnType("date");

                entity.Property(e => e.CreditorDepartment).HasMaxLength(50);

                entity.Property(e => e.CreditorName).HasMaxLength(50);

                entity.Property(e => e.DebtorDateSigned).HasColumnType("date");

                entity.Property(e => e.DebtorDepartment).HasMaxLength(50);

                entity.Property(e => e.DebtorName).HasMaxLength(50);

                entity.Property(e => e.ModificationDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(30);

                entity.Property(e => e.VoucherNo).HasMaxLength(50);

                entity.Property(e => e.VoucherTypeId).HasColumnName("VoucherTypeID");
            });

            modelBuilder.Entity<VoucherDetail>(entity =>
            {
                entity.Property(e => e.VoucherDetailId).HasColumnName("VoucherDetailID");

                entity.Property(e => e.InvoiceId).HasColumnName("InvoiceID");

                entity.Property(e => e.VoucherId).HasColumnName("VoucherID");
            });

            modelBuilder.Entity<VoucherType>(entity =>
            {
                entity.Property(e => e.VoucherTypeId).HasColumnName("VoucherTypeID");

                entity.Property(e => e.VoucherTypeDescription).HasMaxLength(50);
            });
        }
    }
}
