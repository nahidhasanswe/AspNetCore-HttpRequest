﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class MessageDetail
    {
        public int MessageDetailId { get; set; }
        public int? MessageId { get; set; }
        public string Recipient { get; set; }
        public bool? IsSent { get; set; }
    }
}
