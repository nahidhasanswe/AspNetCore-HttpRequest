﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AccessRight
    {
        public int AccessRightId { get; set; }
        public string AccessRightName { get; set; }
    }
}
