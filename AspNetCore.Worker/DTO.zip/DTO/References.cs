﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class References
    {
        public int ReferencId { get; set; }
        public int StudentId { get; set; }
        public string Pin { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public int? RegionCode { get; set; }
        public string OthersRegionName { get; set; }
        public string TelephoneNo { get; set; }
        public string CellPhone { get; set; }
        public short? Status { get; set; }
        public string Relationship { get; set; }

        public Region RegionCodeNavigation { get; set; }
        public Student Student { get; set; }
    }
}
