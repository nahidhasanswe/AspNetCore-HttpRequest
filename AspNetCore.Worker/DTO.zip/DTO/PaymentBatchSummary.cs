﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentBatchSummary
    {
        public int PaymentBatchSummaryId { get; set; }
        public int? PaymentBatchId { get; set; }
        public string InvoiceNo { get; set; }
        public string AccountHead { get; set; }
        public decimal? Amount { get; set; }
    }
}
