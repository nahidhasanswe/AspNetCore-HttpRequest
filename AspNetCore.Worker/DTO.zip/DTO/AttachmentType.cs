﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AttachmentType
    {
        public AttachmentType()
        {
            Attachment = new HashSet<Attachment>();
        }

        public int AttachmentTypeId { get; set; }
        public string AttachmentTypeDescription { get; set; }

        public ICollection<Attachment> Attachment { get; set; }
    }
}
