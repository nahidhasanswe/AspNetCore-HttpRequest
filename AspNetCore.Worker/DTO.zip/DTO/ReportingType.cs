﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ReportingType
    {
        public ReportingType()
        {
            ReportingStatus = new HashSet<ReportingStatus>();
            ReportingTypeValues = new HashSet<ReportingTypeValues>();
        }

        public int ReportingTypeId { get; set; }
        public string Description { get; set; }

        public ICollection<ReportingStatus> ReportingStatus { get; set; }
        public ICollection<ReportingTypeValues> ReportingTypeValues { get; set; }
    }
}
