﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class FinanceRequestType
    {
        public int FinanceRequestTypeId { get; set; }
        public string FinanceRequestTypeName { get; set; }
    }
}
