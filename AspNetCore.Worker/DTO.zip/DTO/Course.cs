﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Course
    {
        public Course()
        {
            AccademicStatus = new HashSet<AccademicStatus>();
            InvoiceDetails = new HashSet<InvoiceDetails>();
            LoanApplication = new HashSet<LoanApplication>();
        }

        public int CourseId { get; set; }
        public int PriorityAreaId { get; set; }
        public string CourseCode { get; set; }
        public string CourseName { get; set; }
        public int? CourseDuration { get; set; }

        public ICollection<AccademicStatus> AccademicStatus { get; set; }
        public ICollection<InvoiceDetails> InvoiceDetails { get; set; }
        public ICollection<LoanApplication> LoanApplication { get; set; }
    }
}
