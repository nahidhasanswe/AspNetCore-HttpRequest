﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InstitutionPaymentMapping
    {
        public int InstitutionPaymentMappingId { get; set; }
        public int InstitutionId { get; set; }
        public int FinanceRequestTypeId { get; set; }
        public decimal? Amount { get; set; }
        public int? ReceivedBy { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public byte? Status { get; set; }
    }
}
