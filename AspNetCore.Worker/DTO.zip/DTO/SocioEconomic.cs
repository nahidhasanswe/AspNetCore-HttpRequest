﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class SocioEconomic
    {
        public int SocioId { get; set; }
        public int ApplicationId { get; set; }
        public int QuestionOptionId { get; set; }
        public decimal? HighestScore { get; set; }
        public decimal? ScoreObtained { get; set; }
        public int? QuestionId { get; set; }
        public string Answer { get; set; }
    }
}
