﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AppliedCourse
    {
        public int AppliedCourseId { get; set; }
        public int? ApplicationId { get; set; }
        public int? CourseId { get; set; }
        public int? ChoiceAs { get; set; }
        public int? Status { get; set; }
    }
}
