﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Parents
    {
        public int ParentId { get; set; }
        public int StudentId { get; set; }
        public int ParentTypeId { get; set; }
        public string Pin { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string PlaceOfBirth { get; set; }
        public string HighestEducation { get; set; }
        public string Telephone { get; set; }
        public string CellPhoneNo { get; set; }
        public int EmploymentStatusId { get; set; }
        public decimal? GrossMonthlyIncome { get; set; }
        public string Employer { get; set; }
        public bool? DisabilityStatus { get; set; }
        public int ChiefCode { get; set; }
        public int IndvunaCode { get; set; }
        public int? RegionCode { get; set; }
        public bool IsSwaziCitizen { get; set; }
        public bool IsAlive { get; set; }
        public byte Status { get; set; }
        public string OthersRegionName { get; set; }

        public EmploymentStatus EmploymentStatus { get; set; }
        public ParentType ParentType { get; set; }
        public Student Student { get; set; }
    }
}
