﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Student
    {
        public Student()
        {
            AcademicInformation = new HashSet<AcademicInformation>();
            Attachment = new HashSet<Attachment>();
            InvoiceDetails = new HashSet<InvoiceDetails>();
            LoanAccount = new HashSet<LoanAccount>();
            LoanApplication = new HashSet<LoanApplication>();
            Parents = new HashSet<Parents>();
            References = new HashSet<References>();
        }

        public int StudentId { get; set; }
        public string Name { get; set; }
        public string MiddleName { get; set; }
        public string Surname { get; set; }
        public string Pin { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string BirthPlace { get; set; }
        public string MaritalStatus { get; set; }
        public string ComputerNo { get; set; }
        public string NationalityId { get; set; }
        public string CountryCode { get; set; }
        public int? ChiefCode { get; set; }
        public int? IndvunaCode { get; set; }
        public int? RegionCode { get; set; }
        public string HomeAddress { get; set; }
        public string PostalAddress { get; set; }
        public string PostCode { get; set; }
        public string Telephone { get; set; }
        public string CellPhone { get; set; }
        public string EmailAddress { get; set; }
        public string SecretCode { get; set; }
        public string VarificationCode { get; set; }
        public string Checksum { get; set; }
        public string TaxNumber { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public byte? StudentStatus { get; set; }
        public int? UploadStatus { get; set; }
        public string UploadMessage { get; set; }
        public string Mountain { get; set; }
        public string River { get; set; }
        public string Nop { get; set; }

        public Chief ChiefCodeNavigation { get; set; }
        public Country CountryCodeNavigation { get; set; }
        public Nationality Nationality { get; set; }
        public Region RegionCodeNavigation { get; set; }
        public ICollection<AcademicInformation> AcademicInformation { get; set; }
        public ICollection<Attachment> Attachment { get; set; }
        public ICollection<InvoiceDetails> InvoiceDetails { get; set; }
        public ICollection<LoanAccount> LoanAccount { get; set; }
        public ICollection<LoanApplication> LoanApplication { get; set; }
        public ICollection<Parents> Parents { get; set; }
        public ICollection<References> References { get; set; }
    }
}
