﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PurchaseOrderDetail
    {
        public int PurchaseOrderDetailId { get; set; }
        public int? PurchasOrderId { get; set; }
        public string ComputerNo { get; set; }
        public string StudentName { get; set; }
        public string SupplierType { get; set; }
        public int? DetailItemId { get; set; }
        public string DetailItem { get; set; }
        public int? Qty { get; set; }
        public decimal? Price { get; set; }
        public int? Status { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CapturedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public int? UploadStatus { get; set; }
        public string UploadMessage { get; set; }
        public decimal? AcademicYear { get; set; }
    }
}
