﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Subject
    {
        public Subject()
        {
            AcademicResult = new HashSet<AcademicResult>();
        }

        public int SubjectId { get; set; }
        public string SubjectName { get; set; }
        public decimal? SubjectCode { get; set; }

        public ICollection<AcademicResult> AcademicResult { get; set; }
    }
}
