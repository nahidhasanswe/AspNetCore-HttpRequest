﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class RepaymentRegister
    {
        public RepaymentRegister()
        {
            RepaymentDetail = new HashSet<RepaymentDetail>();
        }

        public int RepaymentId { get; set; }
        public int SourceTypeId { get; set; }
        public int? PointOfPayId { get; set; }
        public int EmployerId { get; set; }
        public int? BankId { get; set; }
        public DateTime? RepaymentDate { get; set; }
        public decimal? TotalAmount { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public RepaymentSource SourceType { get; set; }
        public ICollection<RepaymentDetail> RepaymentDetail { get; set; }
    }
}
