﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AllowanceMaster
    {
        public AllowanceMaster()
        {
            AllowanceDetails = new HashSet<AllowanceDetails>();
            AllowanceGroupDetails = new HashSet<AllowanceGroupDetails>();
        }

        public int AllowanceId { get; set; }
        public int? InstitutionId { get; set; }
        public string LoanYear { get; set; }
        public int? CourseId { get; set; }
        public int? Period { get; set; }
        public string BatchName { get; set; }
        public short? AllowanceStatus { get; set; }
        public bool? IsLocal { get; set; }
        public int? TotalStudent { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public ICollection<AllowanceDetails> AllowanceDetails { get; set; }
        public ICollection<AllowanceGroupDetails> AllowanceGroupDetails { get; set; }
    }
}
