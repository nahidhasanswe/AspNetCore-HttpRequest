﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AllowanceGroup
    {
        public AllowanceGroup()
        {
            AllowanceGroupDetails = new HashSet<AllowanceGroupDetails>();
            AllowancePayment = new HashSet<AllowancePayment>();
        }

        public int AllowanceGroupId { get; set; }
        public int? TotalNumberOfStudent { get; set; }
        public DateTime? CreationDate { get; set; }

        public ICollection<AllowanceGroupDetails> AllowanceGroupDetails { get; set; }
        public ICollection<AllowancePayment> AllowancePayment { get; set; }
    }
}
