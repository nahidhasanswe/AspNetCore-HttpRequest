﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Industry
    {
        public Industry()
        {
            LoanApplication = new HashSet<LoanApplication>();
        }

        public int IndustryId { get; set; }
        public string IndustryName { get; set; }

        public ICollection<LoanApplication> LoanApplication { get; set; }
    }
}
