﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LoanYearSettings
    {
        public LoanYearSettings()
        {
            LoanApplication = new HashSet<LoanApplication>();
        }

        public string LoanYear { get; set; }
        public DateTime? ApplicationStartDate { get; set; }
        public DateTime ApplicationEndDate { get; set; }
        public int? LoanTypeId { get; set; }
        public short LoanYearStatus { get; set; }
        public string ReviewedBy { get; set; }
        public DateTime? ReviewDate { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovalDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public ICollection<LoanApplication> LoanApplication { get; set; }
    }
}
