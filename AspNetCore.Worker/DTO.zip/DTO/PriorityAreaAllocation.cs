﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PriorityAreaAllocation
    {
        public int PriorityAreaAllocationId { get; set; }
        public int LoanTypeAllocationId { get; set; }
        public int PriorityAreaId { get; set; }
        public decimal PercentageAllocated { get; set; }
        public decimal AverageCost { get; set; }
        public int? TotalNumber { get; set; }
        public decimal? Amount { get; set; }
        public int? InsideCountry { get; set; }
        public int? OutsideCountry { get; set; }

        public LoanTypeAllocation LoanTypeAllocation { get; set; }
        public PriorityArea PriorityArea { get; set; }
    }
}
