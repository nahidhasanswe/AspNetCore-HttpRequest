﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Module
    {
        public Module()
        {
            LogMain = new HashSet<LogMain>();
        }

        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
        public string Description { get; set; }
        public int? Status { get; set; }

        public ICollection<LogMain> LogMain { get; set; }
    }
}
