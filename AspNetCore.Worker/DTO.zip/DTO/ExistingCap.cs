﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ExistingCap
    {
        public int ExistingCapId { get; set; }
        public string Year { get; set; }
        public int? FinanceRequestTypeId { get; set; }
        public int? InstitutionId { get; set; }
        public int? CourseId { get; set; }
        public int? CourseDuration { get; set; }
        public decimal? CapAmount { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
    }
}
