﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LoanType
    {
        public LoanType()
        {
            LoanTypeAllocation = new HashSet<LoanTypeAllocation>();
        }

        public int LoanTypeId { get; set; }
        public string LoanTypeDescription { get; set; }

        public ICollection<LoanTypeAllocation> LoanTypeAllocation { get; set; }
    }
}
