﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InstitutionUploadedResult
    {
        public int InstitutionUploadedResultId { get; set; }
        public int? InstitutionId { get; set; }
        public string ResultTitle { get; set; }
        public int? Status { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public DateTime? ModificationDate { get; set; }
        public string ModifiedBy { get; set; }
    }
}
