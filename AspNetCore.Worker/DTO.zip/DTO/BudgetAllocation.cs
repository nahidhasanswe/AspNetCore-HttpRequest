﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class BudgetAllocation
    {
        public BudgetAllocation()
        {
            LoanTypeAllocation = new HashSet<LoanTypeAllocation>();
        }

        public int BudgetAllocationId { get; set; }
        public string BudgetAllocationYear { get; set; }
        public decimal TotalBudgetAllocation { get; set; }
        public decimal PastYearAllocation { get; set; }
        public decimal CurrentYearInflation { get; set; }
        public decimal OngoingStudentAllocation { get; set; }
        public decimal CurrentYearAllocation { get; set; }
        public decimal RegularLocalStudentPercentage { get; set; }
        public decimal RegularLocalStudentAllocation { get; set; }
        public decimal RegularInternationalStudentPercentage { get; set; }
        public decimal RegularInternationalStudentAllocation { get; set; }
        public decimal? DisableLocalStudentPercentage { get; set; }
        public decimal? DisableLocalStudentAllocation { get; set; }
        public decimal? DisableInternationalStudentPercentage { get; set; }
        public decimal? DisableInternationalStudentAllocation { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public decimal? OverseasPercentage { get; set; }
        public decimal? OverseasAmount { get; set; }

        public ICollection<LoanTypeAllocation> LoanTypeAllocation { get; set; }
    }
}
