﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AcademicResult
    {
        public int ResultId { get; set; }
        public int AcademicInfoId { get; set; }
        public string ExamCenterNo { get; set; }
        public string ExamYear { get; set; }
        public bool? ExamType { get; set; }
        public int SubjectId { get; set; }
        public string StudentExamNo { get; set; }
        public string Score { get; set; }
        public int? Aps { get; set; }
        public short? Status { get; set; }

        public AcademicInformation AcademicInfo { get; set; }
        public Subject Subject { get; set; }
    }
}
