﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Award
    {
        public Award()
        {
            AwardList = new HashSet<AwardList>();
        }

        public int AwardId { get; set; }
        public DateTime? AwardDate { get; set; }
        public string AwardYear { get; set; }
        public string AwardedBy { get; set; }
        public string AwardNotes { get; set; }
        public byte? AwardType { get; set; }

        public ICollection<AwardList> AwardList { get; set; }
    }
}
