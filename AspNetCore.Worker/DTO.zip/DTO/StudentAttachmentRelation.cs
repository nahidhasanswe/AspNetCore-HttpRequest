﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class StudentAttachmentRelation
    {
        public int StudentAttachmentRelationId { get; set; }
        public int StudentId { get; set; }
        public int AttachmentId { get; set; }
        public string Year { get; set; }
    }
}
