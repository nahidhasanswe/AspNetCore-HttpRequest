﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LoanAccount
    {
        public LoanAccount()
        {
            ActualTransaction = new HashSet<ActualTransaction>();
        }

        public int AccountId { get; set; }
        public string LoanYear { get; set; }
        public int StudentId { get; set; }
        public int? AwardListId { get; set; }
        public int? AwardId { get; set; }
        public DateTime? RepaymentStartData { get; set; }
        public string LoanNumber { get; set; }
        public bool? IsForeignStudent { get; set; }
        public int PayeeTypeId { get; set; }
        public int? BankId { get; set; }
        public string BranchCode { get; set; }
        public string BankAccountNo { get; set; }
        public string BankAddress { get; set; }
        public string CountryCode { get; set; }
        public DateTime? AccountCreationDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public string SwiftCode { get; set; }
        public bool? IsApproved { get; set; }
        public bool? IsEnable { get; set; }
        public string AccountName { get; set; }
        public decimal? OpeningBalance { get; set; }

        public Bank Bank { get; set; }
        public PayeeType PayeeType { get; set; }
        public Student Student { get; set; }
        public ICollection<ActualTransaction> ActualTransaction { get; set; }
    }
}
