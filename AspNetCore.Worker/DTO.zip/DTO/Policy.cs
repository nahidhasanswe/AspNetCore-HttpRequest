﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Policy
    {
        public int PolicyId { get; set; }
        public string UniqueNo { get; set; }
        public int? EmployeeId { get; set; }
        public string EmployeeNo { get; set; }
        public int? EmpSourceId { get; set; }
        public int ItemCode { get; set; }
        public int SequenceNo { get; set; }
        public decimal? DeductionAmount { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public decimal PrincipalAmt { get; set; }
        public int? TotalInstallments { get; set; }
        public int? InstallmentCount { get; set; }
        public string PolicyNumber { get; set; }
        public string BankAccno { get; set; }
        public string BankCode { get; set; }
        public string Capturedby { get; set; }
        public DateTime CaptureDate { get; set; }
        public string Reviewedby { get; set; }
        public DateTime? ReviewDate { get; set; }
        public string Appovedby { get; set; }
        public DateTime ApprovedDate { get; set; }
        public string Rejectby { get; set; }
        public DateTime? RejectDate { get; set; }
        public string RejectReason { get; set; }
        public DateTime? ReStartDate { get; set; }
        public DateTime? ReEndDate { get; set; }
        public int? Status { get; set; }
        public int? PolicyType { get; set; }
        public DateTime? SattelmentDate { get; set; }
        public string SattelmentBy { get; set; }
        public int? StattelmentReasonId { get; set; }
        public int? BranchCode { get; set; }
        public int? AuthorizationNo { get; set; }
        public string Comments { get; set; }
        public bool? IsRecordSent { get; set; }
        public DateTime? SuspensionDate { get; set; }
        public int? SkipPeriod { get; set; }
        public string PolicyReferenceNo { get; set; }
    }
}
