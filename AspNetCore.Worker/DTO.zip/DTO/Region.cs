﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Region
    {
        public Region()
        {
            References = new HashSet<References>();
            Student = new HashSet<Student>();
        }

        public int RegionCode { get; set; }
        public string RegionName { get; set; }

        public ICollection<References> References { get; set; }
        public ICollection<Student> Student { get; set; }
    }
}
