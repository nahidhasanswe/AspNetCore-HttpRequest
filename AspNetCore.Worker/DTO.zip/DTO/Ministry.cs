﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Ministry
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
