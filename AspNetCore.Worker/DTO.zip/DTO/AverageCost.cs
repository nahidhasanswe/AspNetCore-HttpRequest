﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AverageCost
    {
        public int AverageCostId { get; set; }
        public string LoanYear { get; set; }
        public int? PriorityAreaId { get; set; }
        public decimal? AverageCost1 { get; set; }
        public int? LoanAreaId { get; set; }
        public int? LoanTypeId { get; set; }
    }
}
