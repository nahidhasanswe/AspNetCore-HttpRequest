﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Invoice
    {
        public int InvoiceId { get; set; }
        public string InvoiceNumber { get; set; }
        public int? PaymentBatchId { get; set; }
        public decimal? InvoiceAmount { get; set; }
        public string Comments { get; set; }
    }
}
