﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Nationality
    {
        public Nationality()
        {
            Student = new HashSet<Student>();
        }

        public string NationalityId { get; set; }
        public string NationalityName { get; set; }

        public ICollection<Student> Student { get; set; }
    }
}
