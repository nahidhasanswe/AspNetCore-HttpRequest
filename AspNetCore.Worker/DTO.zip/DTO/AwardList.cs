﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AwardList
    {
        public int AwardListId { get; set; }
        public int? AwardId { get; set; }
        public int InterviewId { get; set; }
        public string AwardYear { get; set; }
        public string AwardComments { get; set; }
        public DateTime? AwardDate { get; set; }
        public string CapturedBy { get; set; }
        public string ApprovedBy { get; set; }
        public int? Status { get; set; }
        public int? ApplicationId { get; set; }
        public byte? AwardStatus { get; set; }
        public string CheckSum { get; set; }

        public Award Award { get; set; }
    }
}
