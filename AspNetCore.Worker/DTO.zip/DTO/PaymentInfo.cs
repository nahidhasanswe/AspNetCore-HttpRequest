﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentInfo
    {
        public PaymentInfo()
        {
            PaymentDetails = new HashSet<PaymentDetails>();
        }

        public int PaymentInfoId { get; set; }
        public int InvoiceId { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string PayeeName { get; set; }
        public string ChequeNo { get; set; }
        public string BatchNo { get; set; }
        public int? BankId { get; set; }
        public string BranchCode { get; set; }
        public string BankAccountNo { get; set; }
        public string ApprovedBy { get; set; }
        public string ReviewedBy { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public short? PaymentGroup { get; set; }

        public ICollection<PaymentDetails> PaymentDetails { get; set; }
    }
}
