﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Users
    {
        public string UserId { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int? UserTypeId { get; set; }
        public int AccessRight { get; set; }
        public string Telehphone { get; set; }
        public string CellPhone { get; set; }
        public string Email { get; set; }
        public string Network { get; set; }
        public string Macaddress { get; set; }
        public int? TimeSlot { get; set; }
        public int? UserStatus { get; set; }
        public DateTime? RegistryDate { get; set; }
        public byte? Status { get; set; }

        public UserRight AccessRightNavigation { get; set; }
        public UserTypes UserType { get; set; }
    }
}
