﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LoginInfo
    {
        public int SessionId { get; set; }
        public string SessionKey { get; set; }
        public string UserId { get; set; }
        public DateTime? LoginDateTime { get; set; }
        public DateTime? LogoutDate { get; set; }
        public string Ipaddress { get; set; }
        public int? ItemCode { get; set; }
        public int? Status { get; set; }
        public string Macaddress { get; set; }
        public string HostName { get; set; }
        public string InterfaceName { get; set; }
        public string Protocol { get; set; }
        public string PublicIp { get; set; }
        public string InterfaceDescription { get; set; }
    }
}
