﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ExpenseAmount
    {
        public int ExpenseAmountId { get; set; }
        public int LoanTypeId { get; set; }
        public string LoanYear { get; set; }
        public int LoanAreaId { get; set; }
        public byte LoanCategoryId { get; set; }
        public int FinanceRequestTypeId { get; set; }
        public decimal? ExpenseAmount1 { get; set; }
        public decimal? GrantPercentage { get; set; }
        public decimal? LoanAmount { get; set; }
        public int? InstitutionId { get; set; }
        public int? CourseId { get; set; }
        public int StudyYear { get; set; }
        public int? CourseDurationInYears { get; set; }
    }
}
