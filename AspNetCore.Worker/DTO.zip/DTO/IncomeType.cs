﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class IncomeType
    {
        public int IncomeTypeId { get; set; }
        public int AccountMasterCode { get; set; }
        public string Name { get; set; }
    }
}
