﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentBatchDetail
    {
        public PaymentBatchDetail()
        {
            PaymentBatchDetailHeads = new HashSet<PaymentBatchDetailHeads>();
        }

        public int PaymentBatchDetailId { get; set; }
        public int PaymentBatchId { get; set; }
        public int? InvoiceId { get; set; }
        public int? AccountId { get; set; }
        public int? StudentId { get; set; }
        public decimal? Amount { get; set; }
        public string CaptureBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public int? ApplicationId { get; set; }
        public decimal? PayableAmount { get; set; }
        public string ComputerNo { get; set; }
        public string Name { get; set; }
        public string Institution { get; set; }
        public string Course { get; set; }
        public string BatchStatus { get; set; }
        public string MessageText { get; set; }
        public int? UploadStatus { get; set; }
        public string UploadMessage { get; set; }
        public decimal? StudyYear { get; set; }
        public decimal? AcademicYear { get; set; }

        public ICollection<PaymentBatchDetailHeads> PaymentBatchDetailHeads { get; set; }
    }
}
