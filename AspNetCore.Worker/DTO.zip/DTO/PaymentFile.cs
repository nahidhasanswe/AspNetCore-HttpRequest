﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentFile
    {
        public int FileId { get; set; }
        public int? FileType { get; set; }
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public DateTime? DateOfCreation { get; set; }
        public bool? IsProcessed { get; set; }
    }
}
