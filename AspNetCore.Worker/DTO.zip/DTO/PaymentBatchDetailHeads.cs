﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentBatchDetailHeads
    {
        public int PaymentBatchDetailHeadsId { get; set; }
        public int PaymentBatchDetailId { get; set; }
        public int FinanceRequestTypeId { get; set; }
        public decimal? Amount { get; set; }
        public decimal? PayableAmount { get; set; }

        public PaymentBatchDetail PaymentBatchDetail { get; set; }
    }
}
