﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InterestRate
    {
        public int InterestId { get; set; }
        public string LoanYear { get; set; }
        public decimal? InterestRate1 { get; set; }
        public short? IsAuthorized { get; set; }
        public string AuthorizedBy { get; set; }
        public DateTime? AuthorizedDate { get; set; }
    }
}
