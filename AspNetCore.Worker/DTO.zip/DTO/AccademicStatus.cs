﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AccademicStatus
    {
        public int Armid { get; set; }
        public int? StudentId { get; set; }
        public int ApplicationId { get; set; }
        public int? CurrentAcamdemicYear { get; set; }
        public int InstitutionId { get; set; }
        public int CourseId { get; set; }
        public string AccStatus { get; set; }
        public string Notes { get; set; }
        public string ReviewedBy { get; set; }
        public string ApprovedBy { get; set; }
        public string ApprovalComments { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }

        public Course Course { get; set; }
        public Institution Institution { get; set; }
    }
}
