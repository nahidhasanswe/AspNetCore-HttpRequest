﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class VoucherType
    {
        public int VoucherTypeId { get; set; }
        public string VoucherTypeDescription { get; set; }
    }
}
