﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class AllowanceGroupDetails
    {
        public int AllowanceGrpDetailId { get; set; }
        public int? AllowanceGroupId { get; set; }
        public int? AllowanceMasterId { get; set; }

        public AllowanceGroup AllowanceGroup { get; set; }
        public AllowanceMaster AllowanceMaster { get; set; }
    }
}
