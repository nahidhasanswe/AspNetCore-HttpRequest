﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class FundingSource
    {
        public int FundingSourceId { get; set; }
        public string Description { get; set; }
    }
}
