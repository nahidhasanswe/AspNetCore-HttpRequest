﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Interview
    {
        public Interview()
        {
            InterviewResponse = new HashSet<InterviewResponse>();
        }

        public int InterviewId { get; set; }
        public string InterviewYear { get; set; }
        public int ShortListAppsId { get; set; }
        public decimal? InterviewScore { get; set; }
        public bool? IsSocialSipportApproved { get; set; }
        public bool? IsDiabilityApproved { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovalDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public int? LoanDuration { get; set; }

        public ShortListedApplication ShortListApps { get; set; }
        public ICollection<InterviewResponse> InterviewResponse { get; set; }
    }
}
