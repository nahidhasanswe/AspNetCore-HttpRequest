﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LoanApplication
    {
        public int ApplicationId { get; set; }
        public string LoanYear { get; set; }
        public int? LoanTypeId { get; set; }
        public int? FundingSourceId { get; set; }
        public int StudentId { get; set; }
        public int CourseId { get; set; }
        public int IndustryId { get; set; }
        public int InstitutionId { get; set; }
        public int? BatchId { get; set; }
        public int? PriorityAreaId { get; set; }
        public string StudentNumber { get; set; }
        public string ComputerNo { get; set; }
        public string Scnumber { get; set; }
        public DateTime ApplicationDate { get; set; }
        public string Notes { get; set; }
        public short ApplicationStatus { get; set; }
        public bool Ovcstatus { get; set; }
        public bool DisabilityStatus { get; set; }
        public decimal? AnnualCost { get; set; }
        public string ReviewedBy { get; set; }
        public DateTime? ReviewDate { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovalDate { get; set; }
        public string StudentRegNo { get; set; }
        public string Signature { get; set; }
        public string ReferenceNumber { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public byte? LoanCategoryId { get; set; }
        public int? LoanReference { get; set; }
        public int? ApplicationSessionId { get; set; }
        public string EntryYear { get; set; }
        public string ExitYear { get; set; }

        public Course Course { get; set; }
        public Industry Industry { get; set; }
        public LoanYearSettings LoanYearNavigation { get; set; }
        public Student Student { get; set; }
    }
}
