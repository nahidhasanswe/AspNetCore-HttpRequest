﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class TempNationalId
    {
        public int TempNationalIds { get; set; }
        public string NationalId { get; set; }
    }
}
