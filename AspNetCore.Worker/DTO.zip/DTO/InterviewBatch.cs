﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InterviewBatch
    {
        public InterviewBatch()
        {
            InterviewBatchDetails = new HashSet<InterviewBatchDetails>();
        }

        public int InterviewBatchId { get; set; }
        public string InterviewBatchNo { get; set; }
        public string LoanYear { get; set; }
        public int? PriorityAreaId { get; set; }
        public int? LoanAreaId { get; set; }
        public DateTime? InterviewDate { get; set; }
        public DateTime? InterviewTime { get; set; }
        public string InterviewVenue { get; set; }
        public int? TotalNumberOfStudent { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short Status { get; set; }
        public int? EmailSend { get; set; }
        public int? Smssend { get; set; }
        public int? ApplicationSessionId { get; set; }

        public ICollection<InterviewBatchDetails> InterviewBatchDetails { get; set; }
    }
}
