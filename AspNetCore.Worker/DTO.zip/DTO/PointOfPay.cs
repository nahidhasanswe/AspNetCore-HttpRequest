﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PointOfPay
    {
        public int PointOfPayId { get; set; }
        public string Description { get; set; }
    }
}
