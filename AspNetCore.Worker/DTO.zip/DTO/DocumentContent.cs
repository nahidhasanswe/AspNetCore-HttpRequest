﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class DocumentContent
    {
        public long DocumentId { get; set; }
        public int TypeId { get; set; }
        public int ReferenceId { get; set; }
        public string FileName { get; set; }
        public byte[] Content { get; set; }
        public byte Status { get; set; }
        public string CapturedBy { get; set; }
        public DateTime CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
    }
}
