﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InstituteCourseMapping
    {
        public int InstituteCourseMappingId { get; set; }
        public int InstitutionId { get; set; }
        public int CourseId { get; set; }
        public int Status { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
    }
}
