﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class BankTransactionDetail
    {
        public int BankTransactionDetailId { get; set; }
        public int? BankTransactionId { get; set; }
        public DateTime? TransactionDate { get; set; }
        public string Reference { get; set; }
        public decimal? Amount { get; set; }
        public int? MatchedStatus { get; set; }
    }
}
