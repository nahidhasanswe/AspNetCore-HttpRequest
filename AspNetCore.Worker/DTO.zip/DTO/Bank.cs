﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Bank
    {
        public Bank()
        {
            LoanAccount = new HashSet<LoanAccount>();
        }

        public int BankId { get; set; }
        public string BankName { get; set; }
        public string CountryCode { get; set; }

        public ICollection<LoanAccount> LoanAccount { get; set; }
    }
}
