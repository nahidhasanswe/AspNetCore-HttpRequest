﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class EmployeeRepayAllocation
    {
        public int EmployeeRepayAllocationId { get; set; }
        public string ComputerNo { get; set; }
        public int? StudentId { get; set; }
        public decimal? RepayAmount { get; set; }
        public int? EmployerId { get; set; }
        public string EmployerCode { get; set; }
        public byte? Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
