﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class Chief
    {
        public Chief()
        {
            Indvuna = new HashSet<Indvuna>();
            Student = new HashSet<Student>();
        }

        public int ChiefCode { get; set; }
        public string ChiefName { get; set; }

        public ICollection<Indvuna> Indvuna { get; set; }
        public ICollection<Student> Student { get; set; }
    }
}
