﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class PaymentBatch
    {
        public int PaymentBatchId { get; set; }
        public int? FolderId { get; set; }
        public string Year { get; set; }
        public string BatchCode { get; set; }
        public string ChequeNo { get; set; }
        public string VoucherNo { get; set; }
        public string BatchName { get; set; }
        public byte? PayeeCategory { get; set; }
        public int? InstitutionId { get; set; }
        public int? SupplierId { get; set; }
        public decimal? TotalAmount { get; set; }
        public bool? IsCompare { get; set; }
        public bool? NeedToCompare { get; set; }
        public bool? IsFinalized { get; set; }
        public bool? IsPaymentComplete { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string Description { get; set; }
        public string FileReferenceNo { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public string Note { get; set; }

        public Folder Folder { get; set; }
    }
}
