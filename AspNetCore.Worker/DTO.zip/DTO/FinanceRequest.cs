﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class FinanceRequest
    {
        public int FinanceId { get; set; }
        public int ApplicationId { get; set; }
        public int FinanceRequestTypeId { get; set; }
        public decimal? EstimatedFee { get; set; }
        public decimal? ContributedAmount { get; set; }
        public decimal? ExpectedStudyLoan { get; set; }

        public ExpenseType FinanceRequestType { get; set; }
    }
}
