﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class VoucherDetail
    {
        public int VoucherDetailId { get; set; }
        public int? VoucherId { get; set; }
        public int? InvoiceId { get; set; }
        public decimal? InvoiceTotalAmount { get; set; }
        public int? Status { get; set; }
    }
}
