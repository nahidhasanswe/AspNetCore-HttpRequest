﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class BankTransaction
    {
        public int BankTransactionId { get; set; }
        public int? Year { get; set; }
        public int? Month { get; set; }
        public DateTime? TransactionDate { get; set; }
        public string ComputerNumber { get; set; }
        public string EmployerCode { get; set; }
        public decimal? Amount { get; set; }
        public int? Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string Reference { get; set; }
        public decimal? ExpectedAmount { get; set; }
        public int? UploadStatus { get; set; }
        public string UploadMessage { get; set; }
    }
}
