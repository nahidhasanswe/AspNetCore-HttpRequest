﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ParentStatus
    {
        public int ParentStatusId { get; set; }
        public string Description { get; set; }
    }
}
