﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InterviewResponse
    {
        public int InterviewResponseId { get; set; }
        public int InterviewId { get; set; }
        public int QuestionId { get; set; }
        public string QuestionResponse { get; set; }
        public decimal? Score { get; set; }

        public Interview Interview { get; set; }
        public Question Question { get; set; }
    }
}
