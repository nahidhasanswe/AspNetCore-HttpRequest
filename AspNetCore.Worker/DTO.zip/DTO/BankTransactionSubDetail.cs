﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class BankTransactionSubDetail
    {
        public int BankTransactionSubDetailId { get; set; }
        public int? BankTransactionDetailId { get; set; }
        public string Reference { get; set; }
        public string ComputerNo { get; set; }
        public decimal? Amount { get; set; }
        public int? MatchedStatus { get; set; }
        public int? Status { get; set; }
    }
}
