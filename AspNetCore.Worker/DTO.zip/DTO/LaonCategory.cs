﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class LaonCategory
    {
        public byte LaonCategoryId { get; set; }
        public string LoanCategoryName { get; set; }
        public byte? Status { get; set; }
    }
}
