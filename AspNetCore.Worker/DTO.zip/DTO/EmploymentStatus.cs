﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class EmploymentStatus
    {
        public EmploymentStatus()
        {
            Parents = new HashSet<Parents>();
        }

        public int EmploymentStatusId { get; set; }
        public string EmploymentStatusName { get; set; }

        public ICollection<Parents> Parents { get; set; }
    }
}
