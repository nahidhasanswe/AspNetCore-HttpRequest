﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class InstitutionSettings
    {
        public int InstitutionSettingsId { get; set; }
        public int? InstitutionId { get; set; }
        public string LoanYear { get; set; }
        public DateTime? StartDate { get; set; }
        public short? IsAuthorized { get; set; }
        public DateTime? EndDate { get; set; }
        public string AuthorizedBy { get; set; }
        public DateTime? AuthorizedDate { get; set; }
        public string CapturedBy { get; set; }
        public DateTime? CaptureDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModificationDate { get; set; }
        public short? Status { get; set; }
        public int? ApplicationSessionId { get; set; }
    }
}
