﻿using System;
using System.Collections.Generic;

namespace Nybsys.SLAF.Model.DTO
{
    public partial class ReportingTypeValues
    {
        public int ReportingTypeValueId { get; set; }
        public int? ReportingTypeId { get; set; }
        public string Description { get; set; }

        public ReportingType ReportingType { get; set; }
    }
}
